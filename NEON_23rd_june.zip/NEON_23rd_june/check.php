<?php

if(isset($_POST['checkav']))
{	session_start();
	
	if(isset($_SESSION['email']) && isset($_SESSION['name'])){
	$dest=$_POST['dest'];
	$checkindate=$_POST['checkindate'];
	$checkoutdate=$_POST['checkoutdate'];
	$noofbed=$_POST['noofbed'];
	header('location:booking_page.php?dest='.$dest.'&name='.$_SESSION['name'].'&email='.$_SESSION['email'].'&checkindate='.$checkindate.'&checkoutdate='.$checkoutdate.'&noofbed='.$noofbed);
	}
else{
	//$dest=$_POST['dest'];
	$dest=$_POST['dest'];
	$checkindate=$_POST['checkindate'];
	$checkoutdate=$_POST['checkoutdate'];
	$noofbed=$_POST['noofbed'];
	header('location:booking_page.php?dest='.$dest.'&checkindate='.$checkindate.'&checkoutdate='.$checkoutdate.'&noofbed='.$noofbed);
}


}

























?>