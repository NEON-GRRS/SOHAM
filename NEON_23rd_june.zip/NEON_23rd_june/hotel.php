<?php



$db =mysqli_connect('localhost','root','','neon');
$query="SELECT * FROM hotel"; 
$result=mysqli_query($db,$query);
            




?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
 <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->




<!-- jQuery library -->

<meta name="viewport" content="width=device-width, initial-scale=1.0">  


  <meta charset="utf-8">
  
<!----text-------------------------->
<link href='http://fonts.googleapis.com/css?family=Merienda+One' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet' type='text/css'>

<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>
<!--<table>
	<tr>
<th>Pic</th>
<th>Hid</th>
 <th>&nbsp;</th>
<th>Hotel Name</th>
<th>Hotel Type</th>
<th>Total rooms</th>
<th>Price</th>
</tr>-->
<div align="center">  
                     <input type="text" name="search" id="search" class="form-control" />  
                </div>  
                <br>
                <br>
<div class="container headings text-center col-lg-12 col-md-12 col-12">
<div class="card-deck">

 <?php while($row= mysqli_fetch_array($result)){
?>


 <div class="card" style="width:auto" id="hotellist">
    <?php   echo  '<img class="card-img-top" src="'.$row['hotel_pic'].'" alt="Card image" height="250" width="250">'; ?>
            <div class="card-body">
              <h4 class="card-title"><?php echo $row['hotel_name']; ?></h4>
              <p class="card-text"><?php echo $row['hotel_type']; ?></p>
              <p class="card-text"><?php echo $row['total_rooms']; ?></p>
              <p class="card-text" name="price" value="<?php echo $row['hotel_type']; ?>"><?php echo $row['hotel_price']; ?></p>
              <a href="#" class="btn btn-primary">Visit more</a>
            </div>
    


</div>
 






<?php
}
?>


<!--</table>-->

</div>

</div>




  

<script>  
      $(document).ready(function(){  
           $('#search').keyup(function(){  
                search_table($(this).val());  
           });  
           function search_table(value){  
                $('hotellist p').each(function(){  
                     var found = 'false';  
                     $(this).each(function(){  
                          if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0)  
                          {  
                               found = 'true';  
                          }  
                     });  
                     if(found == 'true')  
                     {  
                          $(this).show();  
                     }  
                     else  
                     {  
                          $(this).hide();  
                     }  
                });  
           }  
      });  
 </script>  










<!--------------------------test-card-js-------------------->

<script src="js/jquery.js"></script>
<!--------------------------test-card-js-------------------->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

























</body>
</html>