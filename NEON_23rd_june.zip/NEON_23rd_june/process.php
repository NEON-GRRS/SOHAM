<?php

$uemail="";
$upassword="";
$errors=array();
$db=mysqli_connect('localhost','root','','neon');


if(isset($_POST['login']))
{
	if(empty($_POST['uemail']) || empty($_POST['upassword']))
	{
		array_push($errors, "Email/Password is required");
		
	}
	else
	{
		$uemail=$_POST['uemail'];
		$upassword=$_POST['upassword'];
		$query="SELECT * FROM registration WHERE email='$uemail' AND password =
		'$upassword'";
		$result=mysqli_query($db,$query);
		$row= mysqli_fetch_array($result);
		if($row>0){
			session_start();
			$_SESSION['name']=$row['name'];
			$_SESSION['email']=$row['email'];

			//header('location:index_updated.php?name='.$row['name'].'&email='.$row['email']);
			header('location:'.$_SERVER['PHP_SELF'].'?name='.$_SESSION['name'].'&email='.$_SESSION['email']);
			echo'<script type="text/javascript">alert("Login SuccessFull");</script>';

		}
		else
		{
			//array_push($errors, "Invalid username/password");
			echo'<script type="text/javascript">alert("Invalid email/password");</script>';

		}
	}
}
?>
