<?php 

//database_connection.php

//$db=mysqli_connect('localhost','root','','neon');
$connect =new PDO("mysql:host=localhost;dbname=neon","root","");

?>