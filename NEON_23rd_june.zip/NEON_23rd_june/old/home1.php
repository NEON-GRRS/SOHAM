
<?php include('register.php');?>
<?php include('process.php');?>
<?php include('check.php');?>



<?php 
if(isset($_REQUEST['logout'])){

  echo'
<script type="text/javascript">
        /*window.history.forward();
        function noBack()
        {
            window.history.forward();
        }*/
        window.alert("Successfully logged out");
        history.pushState(null, null, location.href);
        history.back();
        history.forward();
        window.onpopstate = function () { history.go(1); };
</script>';
}

?>





<!DOCTYPE html>
<html>
<head>
	<title>NEON</title>
	<link rel="stylesheet" type="text/css" href="css/style_updated.css">
	<link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/navbar.css">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
 <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->

  <script src="https://www.google.com/recaptcha/api.js" async defer></script>



<!-- jQuery library -->

<meta name="viewport" content="width=device-width, initial-scale=1.0">  


  <meta charset="utf-8">
  
<!----text-------------------------->
<link href='http://fonts.googleapis.com/css?family=Merienda+One' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet' type='text/css'>

<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>




	 <!------------------------------navbar------------------------------------>
    <div class="bgimg">
      <nav class="navbar navbar-expand-md navbar-custom bg-dark navbar-dark  fixed-top">
       <!-- Brand -->
        <a class="navbar-brand" href="#"><img src="image/img11.jfif" alt="logo" width="70px"></a>

       <!-- Toggler/collapsibe Button -->
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
       </button>

        <!-- Navbar links -->
       <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <?php session_start();
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="aboutus.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">About Us</a>';
            }
            else
            {
               echo '<a class="nav-link" href="aboutus.php">About Us</a>';
            }
            ?>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Booking History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Gallery</a>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Top Destinations
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Kolkata</a>
              <a class="dropdown-item" href="#">Asansol</a>
              <a class="dropdown-item" href="#">bhubaneswar</a>
            </div>
          </li>
          <?php 
          if(!isset($_SESSION['name']) && !isset($_SESSION['email'])){
            echo'<li class="nav-item dropdown">

            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Login/Signup
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#" data-target="#mymodel1" data-toggle="modal">Sign Up</a>
              <a class="dropdown-item" href="#" data-target="#mymodel" data-toggle="modal">Login</a>
              
            </div>
            </li>';
          }
          else
          {
          }
           ?>
         
             <li class="nav-item dropdown">
                 <?php
                  
                    if(isset($_SESSION['name']) && isset($_SESSION['email']))
                    {
                       echo '<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                            Your Account
                             </a>';
                              echo '<div class="dropdown-menu">';
                               echo '<a class="dropdown-item" href="user_profile.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">'.$_SESSION['name'].'</a>';
                                  echo '<a class="dropdown-item" href="logout.php?logout" >Logout</a>';

              
                                   echo '</div>';
                    }
                 
             
                    ?>
          
          </li>
          <!--<li class="nav-item mgr-autos" >
            <a class="nav-link" href="#">Log in</a>
          </li>-->
           
      </ul>
              
    </div>
    </nav>
    <div class="container"></div>


	     <div class="container text-center text-white headerset">
	     	<h2> Neon Booking</h2>
	     	<h1>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"where hotel defines your destiny..."</h1>
	     </div>


</div>





<div id="booking" class="section">
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="booking-form">
						<form method="post" action="check.php">
							<div class="row no-margin">
								<div class="col-md-3">
									<div class="form-header">
										
										
										<span class="form-label">Destination</span>
										<input class="form-control" type="text" name="place" placeholder="Country, ZIP, city...">
									
									</div>
								</div>
								<div class=" col-md-7">
									<div class="row no-margin">
										<div class="col-md-4">
											<div class="form-group">
												<span class="form-label">Check In</span>
												<input class="form-control" type="date">
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<span class="form-label">Check out</span>
												<input class="form-control" type="date">
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												<span class="form-label">Guests</span>
												<select class="form-control">
													<option>1</option>
													<option>2</option>
													<option>3</option>
												</select>
												<span class="select-arrow"></span>
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												<span class="form-label">Kids</span>
												<select class="form-control">
													<option>0</option>
													<option>1</option>
													<option>2</option>
												</select>
												<span class="select-arrow"></span>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-btn">
										<input type="submit" class="submit-btn" value="Check availability" name="checkav">
									</div>
								</div>
							</div>
						</form>
					
					</div>
				</div>
			</div>
		</div>
	</div>

















<div class="container headings text-center col-lg-12 col-md-12 col-12">
  <h2 align="text-center">Top-Destinations</h2>
  <p align="text-center">Make Your Dream True</p>
    <div class="card-deck">
      <div class="card" style="width:auto;">
         <img class="card-img-top" src="image/kolkata.jfif" alt="Card image" style="width:auto">
            <div class="card-body">
              <h4 class="card-title">Kolkata</h4>
              <p class="card-text">The city of joy</p>
              <a href="#" class="btn btn-primary">visit more</a>
            </div>
      </div>
      <div class="card" style="width:auto">
         <img class="card-img-top" src="image/asansol.jfif" alt="Card image" style="width:auto;">
            <div class="card-body">
              <h4 class="card-title">asansol</h4>
              <p class="card-text">City of Brotherhood</p>
              <a href="#" class="btn btn-primary">visit more</a>
            </div>
      </div>
      <div class="card" style="width:auto">
         <img class="card-img-top" src="image/bhubaneswar.jfif" alt="Card image" style="width:auto">
            <div class="card-body">
              <h4 class="card-title">Bhubaneswar</h4>
              <p class="card-text">Temple City of India</p>
              <a href="#" class="btn btn-primary">Visit more</a>
            </div>
     </div>
  </div>
</div>

<br><br>
<br><br>

<div class="testimonials text-center">
	<h1>Testimonials</h1>

</div>











<!-------------under working (testimonial part)-------------------->

<section class="carousel slide" data-ride="carousel" id="postsCarousel">
    <!--div class="container">
        <div class="row">
            <div class="col-xs-12 text-md-right lead">
                <a class="btn btn-outline-secondary prev" href="js/jquery.js" title="go back"><i class="fa fa-lg fa-chevron-left"></i></a>
                <a class="btn btn-outline-secondary next" href="" title="more"><i class="fa fa-lg fa-chevron-right"></i></a>
            </div-->
       <!-- </div>
    </div>-->
    <div class="container p-t-0 m-t-2 carousel-inner">
        <div class="row row-equal carousel-item active m-t-0">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-img-top card-img-top-250">
                        <img class="img-fluid" src="image/m1.jfif" alt="Carousel 1">
                    </div>
                    <div class="card-block p-t-2">
                         <h3>Name,Designations</h3><br><br>
                        <h2>
                             <p>ITS AWESOME!!,jhvgdkhbgjvtvfjyfdcvhtdhvtffjybjvdchtrdvhtrvdhtrdhtrvdhtrdvhtrvdhtrdvhtfrcjbytgbfjgvdhbdcfjgvdd</p>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-img-top card-img-top-250">
                        <img class="img-fluid" src="image/m2.jfif" alt="Carousel 2">
                    </div>
                    <div class="card-block p-t-2">
                        <h3>Name,Designations</h3><br><br>
                        <h2>
                             <p>ITS AWESOME!!,jhvgdkhbgjvtvfjyfdcvhtdhvtffjybjvdchtrdvhtrvdhtrdhtrvdhtrdvhtrvdhtrdvhtfrcjbytgbfjgvdhbdcfjgvdd</p>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-img-top card-img-top-250">
                        <img class="img-fluid" src="image/m3.jfif" alt="Carousel 3">
                    </div>
                    <div class="card-block p-t-2">
                         <h3>Name,Designations</h3><br><br>
                        <h2>
                             <p>ITS AWESOME!!,jhvgdkhbgjvtvfjyfdcvhtdhvtffjybjvdchtrdvhtrvdhtrdhtrvdhtrdvhtrvdhtrdvhtfrcjbytgbfjgvdhbdcfjgvdd</p>
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row row-equal carousel-item m-t-0">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-img-top card-img-top-250">
                        <img class="img-fluid" src="image/m4.jfif" alt="Carousel 4">
                    </div>
                    <div class="card-block p-t-2">
                        <h3>Name,Designations</h3><br><br>
                        <h2>
                             <p>ITS AWESOME!!,jhvgdkhbgjvtvfjyfdcvhtdhvtffjybjvdchtrdvhtrvdhtrdhtrvdhtrdvhtrvdhtrdvhtfrcjbytgbfjgvdhbdcfjgvdd</p>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-img-top card-img-top-250">
                        <img class="img-fluid" src="image/m5.jfif" alt="Carousel 5">
                    </div>
                    <div class="card-block p-t-2">
                         <h3>Name,Designations</h3><br><br>
                        <h2>
                             <p>ITS AWESOME!!,jhvgdkhbgjvtvfjyfdcvhtdhvtffjybjvdchtrdvhtrvdhtrdhtrvdhtrdvhtrvdhtrdvhtfrcjbytgbfjgvdhbdcfjgvdd</p>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4 fadeIn wow">
                <div class="card">
                    <div class="card-img-top card-img-top-250">
                        <img class="img-fluid" src="image/m6.jfif" alt="Carousel 6">
                    </div>
                    <div class="card-block p-t-2">
                        <h3>Name,Designations</h3><br><br>
                        <h2>
                             <p>ITS AWESOME!!,jhvgdkhbgjvtvfjyfdcvhtdhvtffjybjvdchtrdvhtrvdhtrdhtrvdhtrdvhtrvdhtrdvhtfrcjbytgbfjgvdhbdcfjgvdd</p>
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-------------under working (testimonial part end)-------------------->

<!---------------------------------------- Login / SIgn up -------------------------------------->

<div class="container">
    <div class="modal" id="mymodel">
      <div class="modal-dialog ">
        
        <div class="modal-content">
                <div class= "modal-header">
                    <button type="button" class="close" data-dismiss="modal"> &times;</button>
                </div>
        
            <div class="modal-body">
         
        
                      <center><h3 class="text-primary">Login</h3></center>
                      <center><p style="font-size:20px">Login Using Social accounts</p></center> 

            
                      <center>
                         <label><a href="#" class="fa fa-facebook"></a>
                          <a href="#" class="fa fa-twitter"></a>
                          <a href="#" class="fa fa-google"></a></label>
                      </center>
            
                           &nbsp;&nbsp;&nbsp;
                      <center><p style="font-size:20px">or</p></center> 
          
                    <form id="mylogin" method="post" action="home.php">
                       
                      <div class="form-group">
                        <input type="email" name="uemail" placeholder="Email" class="form-control" required />

                      </div>
                      <div class="form-group">
                         <input type="password" name="upassword" placeholder="Password" class="form-control" required />

                      </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <div class="checkbox">
                         <label><input type="checkbox" value="">Remember me</label>
                          &nbsp;&nbsp;

                       <a href="#" class="btn btn-link">Forget password?</a> 
                       </div>
                      <div class="modal-footer justify-content-center">
                       <input type="submit" class="btn btn-success" name="login" value="Login">
                      </div>
            
                    </form>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            </div>
        </div>
            </div>
          


          </div>

      </div>

  




<div class="container">
    <div class="modal" id="mymodel1">
      <div class="modal-dialog ">
        
        <div class="modal-content">
          <div class= "modal-header">
          <button type="button" class="close" data-dismiss="modal"> &times;</button>
        </div>
        
            <div class="modal-body">

              <center><h3 class="text-primary">Signup</h3></center>
              <center><p style="font-size:20px">Create your account</p></center> 

              

            <form id="mysignup" method="post" action="home.php">
              <div class="form-group">
                <input type="text" name="name" placeholder="Full name" class="form-control" required />

              </div>
              
              <div class="form-group">
                <input type="email" name="email" placeholder="Email" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="password" name="password" placeholder="Password" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="text" name="mobno" placeholder="Mobile No" class="form-control" required />

              </div>
             
                <div class="form-group">

                <input type="date" name="dob" placeholder="DoB(dd\mm\yy)" class="form-control" required />

              </div>

          

              <center><div class="g-recaptcha" data-sitekey="6LeVOvIUAAAAAK_9Pzhoa-KkS2XzQjcz1gUJDFIB" required>
          
             </div></center>
              <div class="modal-footer justify-content-center">
              <input type="submit" class="btn btn-danger"  name="signup" value="Signup">
            </div>
            </form>
            
          </div>
            </div>
          


          </div>
        


        </div>


      </div>

  
      

  </div>




























<!--footer part_------_--------------------->

	<div class="footer">
		<div class="inner-footer">
			<div class="footer-items">
				<h1 class="footer-h1">NEON</h1>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus velit ducimus, enim inventore earum, eligendi nostrum pariatur necessitatibus eius dicta a voluptates sit deleniti autem error eos totam nisi neque voluptates sit deleniti autem error eos totam nisi neque.</p>
			</div>
		<div class="footer-items">
			<h2 class="footer-h2">Quick Links</h2>
			<div class="border-footer"></div>
			<ul>
				<a href=""><li>Home</li></a>
				<a href=""><li>About Us</li></a>
				<a href=""><li>Contact Us</li></a>
			</ul>
		</div>
		<div class="footer-items">
			<h2 class="footer-h2">Services</h2>
			<div class="border-footer"></div>
			<ul>
				<a href=""><li>Hotels</li></a>
				<a href=""><li>Paying Guests</li></a>
				<a href=""><li>Car Rentals</li></a>
			</ul>
		</div>
		<div class="footer-items">
			<h2 class="footer-h2">Contact Us</h2>
			<div class="border-footer"></div>
			<ul>
				<li><i class="fa fa-map-marker" aria-hidden="true"></i>XYZ Street, Kolkata</li>
				<li><i class="fa fa-phone" aria-hidden="true"></i>1234567896</li>
				<li><i class="fa fa-envelope" aria-hidden="true"></i>support@neon.com</li>
			</ul>
		</div>
		<div class="social-media">
				<a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
				<a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
				<a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
				<a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
		</div>
</div>
	</div>
	<div class="footer-bottom">
		Copyright &copy; Neon 2020. All rights reserved.
	</div>
</div>







<!--------------------------test-card-js-------------------->

<script src="js/jquery.js"></script>
<!--------------------------test-card-js-------------------->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>








<script type="text/javascript">
  



function noBack(){

var url = new URL(document.URL);
var search_params = url.searchParams;
var lout = search_params.get('logout');


if(lout.match(out))
{
 window.history.forward();
        function blockBack()
        {
            window.history.forward();
        }
}
}



</script>

























</body>
</html>