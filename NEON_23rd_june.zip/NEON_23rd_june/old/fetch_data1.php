<?php

//fetch_data.php

include('database_connection.php');
//$con = new mysqli("localhost","root","","neon");
//$conn =new PDO("mysql:host=localhost;dbname:neon","root","");

if(isset($_POST['action']) && isset($_POST['dest']))
{
	$dest=$_POST['dest'];
	$query = "SELECT * FROM hotel WHERE hotel_loc='$dest'";
	if(isset($_POST["minimum_price"], $_POST["maximum_price"]) && !empty($_POST["minimum_price"]) && !empty($_POST["maximum_price"]))
	{
		$query .= "
		 AND hotel_price BETWEEN '".$_POST["minimum_price"]."' AND '".$_POST["maximum_price"]."'
		";
	}
	if(isset($_POST['hotel_type']))
	{
		$type_filter = implode("','", $_POST['hotel_type']);
		$query .= "
		 AND hotel_type IN('".$type_filter."');
		";
	}
	if(isset($_POST["hotel_rating"]))
	{
		$rating_filter = implode("','", $_POST["hotel_rating"]);
		$query .= "
		 AND hotel_rating IN('".$rating_filter."')
		";
	}
	if(isset($_POST["hotel_chain"]))
	{
		$chain_filter = implode("','", $_POST["hotel_chain"]);
		$query .= "
		 AND hotel_chain IN('".$chain_filter."')
		";
	}
	if(isset($_POST["amenities_name"]))
	{
		$am_filter = implode("','", $_POST["amenities_name"]);
		/*$query .= "
		 AND hotel_amenities IN('".$am_filter."')
		";*/
		$query .= "
		 AND hotel_id IN ( SELECT hotel_id FROM amenities  WHERE hotel.hotel_id=amenities.hotel_id AND amenities_name IN('".$am_filter."'))
		";
	}


	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$total_row = $statement->rowCount();
	$output = '';

	/*$result=mysqli_query($db,$query)  or die("Error: ".mysqli_error($db));

	$row= mysqli_fetch_array($result);*/
	/*$result=$con->query($query);
	$output='';*/

	if($total_row > 0)
	{
		foreach($result as $row) 
		{
			$output .= '
			<div class="col-sm-4 col-lg-3 col-md-3">
				<div style="border:1px solid #ccc; border-radius:5px; padding:20px; margin-bottom:20px; height:650px; ">
					<img src="'. $row['hotel_pic'] .'" alt="" class="img-responsive" height="275" width="275">
					<p align="center"><strong><a href="#">'. $row['hotel_name'] .'</a></strong></p>
					<h5 style="text-align:center;" class="text-danger" >'. $row['hotel_price'] .'</h5>
					<p> '. $row['hotel_type'].' <br />
					User Rating : '. $row['hotel_rating'] .' <br />
					 '. $row['hotel_chain'] .' <br /></p>';
	
			$hotel_id=$row['hotel_id'];
			$query1= "SELECT amenities_name FROM amenities WHERE hotel_id='$hotel_id'";
			$statement1 = $connect->prepare($query1);
			$statement1->execute();
			$result1 = $statement1->fetchAll();
			$total_row1 = $statement1->rowCount();
			if($total_row1>0){
				foreach ($result1 as $row1) {

					$output .='<p>'.$row1['amenities_name'].'</p>
					</div>
				</div>';
				}
			}
			/*$output .= '
			<div class="col-sm-4 col-lg-3 col-md-3">
				<div class="card"  id="hotellist">
					<div class="card-body" >
  						<img class="img-responsive" src="'.$row['hotel_pic'].'" alt="Card image" height="275" width="275">
            
             			 <h4>'.$row['hotel_name'].'</h4>
              			 <p>'.$row['hotel_type'].'</p><br/>
             			<p> User Rating : '. $row['hotel_rating'] .' <br />
					 	 '. $row['hotel_chain'] .' <br />
					     '. $row['hotel_amenities'] .'  </p>
              			<p class="card-text" name="price" value="'.$row['hotel_type'].'">'.$row['hotel_price'].'</p>
              			<a href="#" class="btn btn-primary">Visit more</a>
            		</div>
            	</div>
            </div>';*/
    


		}
	}
	else
	{
		$output = '<h3>No Data Found</h3>';
	}
	echo $output;
}

?>