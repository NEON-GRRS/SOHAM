<?php include('register.php');?>
<?php include('process.php');?>
<?php include('database_connection.php'); ?>
<?php include('book_login.php'); ?>
<?php
  session_start();
if(isset($_REQUEST['hotel_id']) && isset($_REQUEST['dest']) && isset($_REQUEST['checkindate']) && isset($_REQUEST['checkoutdate']) && isset($_REQUEST['noofbed'])){

  $_SESSION['hotel_id']=$_REQUEST['hotel_id'];
  $_SESSION['dest']=$_REQUEST['dest'];
  $_SESSION['checkindate']=$_REQUEST['checkindate'];
  $_SESSION['checkoutdate']=$_REQUEST['checkoutdate'];
  $_SESSION['noofbed']=$_REQUEST['noofbed'];
}
?>

   


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/about.css">
  <link rel="stylesheet" href="css/navbar.css">
  <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/hotel_description.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="footer.css">
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>
     <style type="text/css">
       
      #map{
        height: 200px;
        width: auto;
      }



     </style>
  </head>
  <body>
    <!------------------------------navbar------------------------------------>
  <div class="bgimg">
      <nav class="navbar navbar-expand-md navbar-custom bg-dark navbar-dark fixwd-top ">
       <!-- Brand -->
        <a class="navbar-brand" href="#"><img src="image/img11.jfif" alt="logo" width="70px"></a>

       <!-- Toggler/collapsibe Button -->
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
       </button>

        <!-- Navbar links -->
       <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <?php 
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="home.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">Home</a>';
            }
            else
            {
               echo '<a class="nav-link" href="home.php">Home</a>';
            }
            ?>
           </li>
            <li class="nav-item">
              <?php
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="aboutus.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">About Us</a>';
            }
            else
            {
               echo '<a class="nav-link" href="aboutus.php">About us</a>';
            }
            ?>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Booking History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Gallery</a>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Top Destinations
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Kolkata</a>
              <a class="dropdown-item" href="#">Asansol</a>
              <a class="dropdown-item" href="#">bhubaneswar</a>
            </div>
          </li>
          
          <?php 
          if(!isset($_SESSION['name']) && !isset($_SESSION['email'])){
            echo'<li class="nav-item dropdown">

            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Login/Signup
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#" data-target="#mymodel1" data-toggle="modal">Sign Up</a>
              <a class="dropdown-item" href="#" data-target="#mymodel" data-toggle="modal">Login</a>
              
            </div>
            </li>';
          }
          else
          {
          }
           ?>
          
             <li class="nav-item dropdown">
                 <?php
                  
                    if(isset($_SESSION['name']) && isset($_SESSION['email']))
                    {
                       echo '<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                            Your Account
                             </a>';
                              echo '<div class="dropdown-menu">';
                               echo '<a class="dropdown-item" href="user_profile.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">'.$_SESSION['name'].'</a>';
                                  echo '<a class="dropdown-item" href="logout.php?logout">Logout</a>';

              
                                   echo '</div>';
                    }
                 
             
                    ?>
          </li>
          <!--<li class="nav-item mgr-autos" >
            <a class="nav-link" href="#">Log in</a>
          </li>-->
           
      </ul>
              
    </div>
    </nav>
  
</div>

<!--------navbar end------>
<!---------------------------------------- Login / SIgn up -------------------------------------->

<!---------------------------------------- Login / SIgn up -------------------------------------->
<div class="container">
    <div class="modal" id="mymodel">
      <div class="modal-dialog ">
        
        <div class="modal-content">
                <div class= "modal-header">
                    <button type="button" class="close" data-dismiss="modal"> &times;</button>
                </div>
        
            <div class="modal-body">
         
        
                      <center><h3 class="text-primary">Login</h3></center>
                      <center><p style="font-size:20px">Login Using Social accounts</p></center> 

            
                      <center>
                         <label><a href="#" class="fa fa-facebook"></a>
                          <a href="#" class="fa fa-twitter"></a>
                          <a href="#" class="fa fa-google"></a></label>
                      </center>
            
                           &nbsp;&nbsp;&nbsp;
                      <center><p style="font-size:20px">or</p></center> 
          
                    <form id="mylogin" method="post" action="book_login.php">
                       
                      <div class="form-group">
                        <input type="email" name="uemail" placeholder="Email" class="form-control" required />

                      </div>
                      <div class="form-group">
                         <input type="password" name="upassword" placeholder="Password" class="form-control" required />

                      </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <div class="checkbox">
                         <label><input type="checkbox" value="">Remember me</label>
                          &nbsp;&nbsp;

                       <a href="#" class="btn btn-link">Forget password?</a> 
                       </div>
                      <div class="modal-footer justify-content-center">
                       <input type="submit" class="btn btn-success" name="login" value="Login">
                      </div>
            
                    </form>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            </div>
        </div>
            </div>
          


          </div>

      </div>

  




<div class="container">
    <div class="modal" id="mymodel1">
      <div class="modal-dialog ">
        
        <div class="modal-content">
          <div class= "modal-header">
          <button type="button" class="close" data-dismiss="modal"> &times;</button>
        </div>
        
            <div class="modal-body">

              <center><h3 class="text-primary">Signup</h3></center>
              <center><p style="font-size:20px">Create your account</p></center> 

              

            <form id="mysignup" method="post" action="aboutus.php">
              <div class="form-group">
                <input type="text" name="name" placeholder="Full name" class="form-control" required />

              </div>
              
              <div class="form-group">
                <input type="email" name="email" placeholder="Email" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="password" name="password" placeholder="Password" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="text" name="mobno" placeholder="Mobile No" class="form-control" required />

              </div>
             
           
          

              <center><div class="g-recaptcha" data-sitekey="6LeVOvIUAAAAAK_9Pzhoa-KkS2XzQjcz1gUJDFIB" required>
          
             </div></center>
              <div class="modal-footer justify-content-center">
              <input type="submit" class="btn btn-danger"  name="signup" value="Signup">
            </div>
            </form>
            
          </div>
            </div>
          


          </div>
        


        </div>


      </div>

  
      

  </div>


<!---------------------------------------- description -------------------------------------->
<div class="outer">
  <br />
  <div class="main_box container" data-spy="scroll" data-target=".navbar" data-offset="50" >
    <br />
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top" style="border:2px solid;border-radius:12px;">
      <a href="#"  class="logo" style="font-size: 2em;">

        <?php
        $hotel_id=$_SESSION['hotel_id'];

          $query="SELECT * FROM hotel WHERE hotel_id =
            '$hotel_id'";
          $statement = $connect->prepare($query);
          $statement->execute();
          $result = $statement->fetchAll();
          $total_row = $statement->rowCount();
          foreach ($result as $row) {
            $output=$row['hotel_name'];
          }
          
        ?>








      <?php echo $output;?></a>  
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleSubNavbar">
            <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="collapsibleSubNavbar" style="text-align: right;">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="#overview">Overview</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#rooms">Rooms</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#gallery">Gallery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#location">Location</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#amenities">Amenities</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#olicies">Policies</a>
          </li>    
          <li class="nav-item">
            <a class="nav-link" href="#reviews">Reviews</a>
          </li>

        </ul>
      </div>
    </nav> 
    <br />
    <div class="row container-fluid">
      <div class="column" style="width: 52%;">
        <div id="demo" class="carousel slide " data-ride="carousel">

          <!-- Indicators -->
          <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
          </ul>
          
          <!-- The slideshow >
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="image/img1.jpg" alt="img1" height="100%">
            </div>
            <div class="carousel-item">
              <img src="image/img2.jpg" alt="img2">
            </div>
            <div class="carousel-item">
              <img src="image/img3.jpg" alt="img3" >
            </div>
          </div-->
          <?php
        $picquery="SELECT * FROM hotel_pics WHERE hotel_id='$hotel_id'";
        $statement = $connect->prepare($picquery);
         $statement->execute();
        $picresult = $statement->fetchAll();
         $total_row = $statement->rowCount();

         if($total_row > 0){

            
            $pic_count=0;
            $flag=0;

            foreach($picresult as $row){
              if($pic_count<=2){
                if($flag==0){
                
                  echo '<div class="carousel-inner" style="height: auto;">
                        <div class="carousel-item active">
                          <img src="'.$row['hotel_pictures'].'" alt="img1" >
                        </div>';
                  $flag=1;
                  $pic_count++;

                }
                else{

                    echo '<div class="carousel-item ">
                            <img src="'.$row['hotel_pictures'].'" alt="img2"  >
                          </div>';
                     $pic_count++;

                }
              }
              else{
                break;
              }
              
            }
          }

        ?>
        </div>
          
          <!-- Left and right controls -->
          <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
          </a>
          <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
          </a>
        </div>
      </div>
      <!--div class="column" style="width: 4%;"></div-->
      <div class="column" style="width: 2%;"></div>
      <div class="column" style="width:46%;">
        <div id="location" class="container-fluid location_style" style="padding-top:35px;padding-bottom: 10px;">
          <h1 class="h1">location</h1>
          
          <!--p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p-->
         <div id="map"></div>
        <?php
        /*$lat=22.579751;
        $lng=88.461100;

        */
        $posquery="SELECT * FROM hotel WHERE hotel_id='$hotel_id'";
        $statement = $connect->prepare($posquery);
         $statement->execute();
        $posresult = $statement->fetchAll();
         $total_row = $statement->rowCount();
         if($total_row > 0){
            foreach($posresult as $row){
              $lat = $row['hotel_lat'];
              $lng = $row['hotel_lng'];
            }
          }

        ?>
        <script>
          function initMap() {
            var location ={lat: <?php echo $lat; ?>, lng: <?php echo $lng; ?>};
            var map =new google.maps.Map(document.getElementById("map"),{
                zoom: 16,
                center: location
            });
            var marker =new google.maps.Marker({
                position: location,
                map: map
            });
          }
        </script>
          <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCng70lMiT1nAJjaECBtWEceBpKnJQELXw&callback=initMap"
          type="text/javascript"></script>





























       </div>
      </div>
    </div>

    <br />
    <div id="rooms" class="container-fluid room_style" style="padding-top:30px;padding-bottom:30px;background-color: transparent; ">
      <h1>Rooms:</h1><br />




      <!----------------------------------roooom section ---------------------------------------------------->
      

      <div class="row">
        <!div class="card"-->
          <?php
                  $roomquery="SELECT * FROM room WHERE hotel_id='$hotel_id'";
                  $statement = $connect->prepare($roomquery);
                   $statement->execute();
                  $roomresult = $statement->fetchAll();
                   $total_row = $statement->rowCount();
                  if($total_row > 0){
                      foreach($roomresult as $row){
                        echo'&nbsp&nbsp
                            <div class="col-sm-4 col-lg-3 col-md-3" style="border:1px solid white; border-radius:12px;padding-left:50px;background-color:white;box-shadow:5px 5px 10px violet;">
                            <img src="'. $row['room_logo'] .'" alt="" class="img-responsive" height="160px" width="180px"style="border:1px solid #ccc; border-radius:10px;">
                             <div class="details" style="padding-left:15px;">
                               <p text-align="center">Room Type:<br />'.$row['room_type'].'</p>
                                 <p>Total Capaciy:<br />'.$row['room_capacity'].'</p><br/>
                                  <p>Price Starts from:<br />'.$row['room_price'].'</p>';
                                if(isset($_SESSION['name']) && isset($_SESSION['email'])){


                                echo  '<a class="btn btn-primary" href="confirmation.php?room_id='.$row['room_id'].'">BOOK</a>
                             </div>
                              </div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
                            }
                            else{
                      

                        echo '<a class="btn btn-primary" href="#" data-target="#mymodel" data-toggle="modal">BOOK</a> </div>
                        </div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';


                    }


                      }
                  }
         ?>
      
      </div>

   </div>
    <br />
    <div id="gallery" class="container-fluid gallery_style" style="padding-top:70px;padding-bottom:70px">
      <h1>Gallery</h1>
      <div class="container">
       <div class="row">
          <div class="col-md-3">
           <div class="thumbnail">
             <a href="image/g1.jfif" target="_blank">
               <img src="image/g1.jfif" alt="Lights" style="width:100%;height: 130px;">
               <div class="caption">
                 <p>luxor bed</p>
               </div>
             </a>
           </div>
          </div>
          <div class="col-md-3">
           <div class="thumbnail">
             <a href="image/g2.jfif" target="_blank">
               <img src="image/g2.jfif" alt="Nature" style="width:100%;height: 130px;">
               <div class="caption">
                 <p>beds......</p>
               </div>
             </a>
           </div>
         </div>
         <div class="col-md-3">
           <div class="thumbnail">
             <a href="image/g3.jfif" target="_blank">
               <img src="image/g3.jfif" alt="Fjords" style="width:100%;height: 130px;">
                <div class="caption">
                  <p>beds</p>
               </div>
             </a>
            </div>
         </div>
         <div class="col-md-3">
           <div class="thumbnail">
             <a href="image/g9.jfif" target="_blank">
               <img src="image/g9.jfif" alt="Fjords" style="width:100%;height: 130px;">
                <div class="caption">
                  <p>beds</p>
               </div>
             </a>
            </div>
         </div>
       </div>
       <div class="row">
          <div class="col-md-3">
           <div class="thumbnail">
             <a href="image/g4.jfif" target="_blank">
               <img src="image/g4.jfif" alt="Lights" style="width:100%;height: 130px;">
               <div class="caption">
                 <p>luxor bed</p>
               </div>
             </a>
           </div>
          </div>
          <div class="col-md-3">
           <div class="thumbnail">
             <a href="image/g5.jfif" target="_blank">
               <img src="image/g5.jfif" alt="Nature" style="width:100%;height: 130px;">
               <div class="caption">
                 <p>beds......</p>
               </div>
             </a>
           </div>
         </div>
         <div class="col-md-3">
           <div class="thumbnail">
             <a href="image/g6.jfif" target="_blank">
               <img src="image/g6.jfif" alt="Fjords" style="width:100%;height: 130px;">
                <div class="caption">
                  <p>beds</p>
               </div>
             </a>
            </div>
         </div>
         <div class="col-md-3">
           <div class="thumbnail">
             <a href="image/g10.jfif" target="_blank">
               <img src="image/g10.jfif" alt="Fjords" style="width:100%;height: 130px;">
                <div class="caption">
                  <p>beds</p>
               </div>
             </a>
            </div>
         </div>
       </div>

      </div>
    </div>
    <br />
    <div id="amenities" class="container-fluid amenities_style" style="padding-top:70px;padding-bottom:70px">
      <h1>amenities</h1>
      <div class="row">
        <?php

      /*$roomquery="SELECT * FROM room WHERE hotel_id='$hotel_id'";
      $roomresult=mysqli_query($db,$roomquery);
      
   
         
      while($roomrow= mysqli_fetch_array($roomresult)) {
          echo '<p>'.$roomrow['room_id'].'</p>';
          
        }*/
        $amquery="SELECT * FROM amenities WHERE hotel_id='$hotel_id'";
        $statement = $connect->prepare($amquery);
         $statement->execute();
        $amresult = $statement->fetchAll();
         $total_row = $statement->rowCount();
        if($total_row > 0){
            foreach($amresult as $row){
              echo'<div class="col-sm-4 col-lg-3 col-md-3">
                      <center><img src="'. $row['amenities_pic'] .'" alt="" class="img-responsive" height="160px" width="180px"style="border:1px solid #ccc; border-radius:10px;"">
                      <p>'.$row['amenities_name'].'</p></center>
                      

                    </div>';


            }
        }




    ?>
  </div>
    </div>
    <br />
    <div id="policies" class="container-fluid policies_style" style="padding-top:70px;padding-bottom:70px">
      <h1>Policies</h1>
      <p>section is blank for hotel authrity</p>
    </div>
    <br />
    <div id="about" class="container-fluid about_style" style="padding-top:70px;padding-bottom:70px">
      <h1>About the property</h1>
      <p>fetch data from databaseby creating a table @rudra</p>
    </div>
    <br />
    <div id="reviews" class="container-fluid review_style" style="padding-top:70px;padding-bottom:70px">
      <h1>reviews</h1>
      <div id="demo1" class="carousel slide" data-ride="carousel">

    <!-- Indicators -->
    <ul class="carousel-indicators">
      <li data-target="#demo1" data-slide-to="0" class="active"></li>
      <li data-target="#demo1" data-slide-to="1"></li>
      <li data-target="#demo1" data-slide-to="2"></li>
    </ul>
    
    <!-- The slideshow -->
    <div class="carousel-inner">
      <div class="carousel-item active">
        <div class="card card_tes" style="height:250px;background-color: grey; ">
          <div class="row">
            <div class="column" >
             <div class="img" style="padding-left: 55px;">
               <img src="image/m1.jfif" style="clip-path: circle(30% at 50% 50%);">
              </div>
            </div>
            <div class="column">
              <div class="v" style="border-left:2px solid blue;">
              
              </div>
           </div>
           <div class="column">
              <div style="padding-left: 50px;padding-top: 80px;">
                <p style="font-family:Comic Sans MS, cursive, sans-serif;"><i class="fa fa-quote-left" style="font-size:48px;color:white"></i>
               review and all fetched from database or from the file in offline mode
                <i class="fa fa-quote-right" style="font-size:48px;color:white"></i></p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item">
       <div class="card card_tes" style="height:250px;background-color: grey; ">
        <div class="row">
          <div class="column" style="padding-left: 55px;">
            <img src="image/m3.jfif" style="clip-path: circle(30% at 50% 50%);">
          </div>
          <div class="column">
            <div class="v" style="border-left:2px solid blue;"></div>
          </div>
          <div class="column">
            <div style="padding-left: 50px;padding-top: 80px;">
              <p style="font-family:Comic Sans MS, cursive, sans-serif;"><i class="fa fa-quote-left" style="font-size:48px;color:white"></i>
               review and all fetched from database or from the file in offline mode
              <i class="fa fa-quote-right" style="font-size:48px;color:white"></i></p>
            </div>
          </div>
        </div>
        </div>
      </div>
      <div class="carousel-item">
        <div class="card cars_tes"  style="height:250px;background-color: grey; ">
        <div class="row">
          <div class="column" style="padding-left: 55px;">
            <img src="image/m5.jfif" style="clip-path: circle(30% at 50% 50%);">
          </div>
          <div class="column">
            <div class="v" style="border-left:2px solid blue;"></div>
          </div>
          <div class="column">
            <div style="padding-left: 50px;padding-top: 80px;">
              <p style="font-family:Comic Sans MS, cursive, sans-serif;"><i class="fa fa-quote-left" style="font-size:48px;color:white"></i>
               review and all fetched from database or from the file in offline mode
              <i class="fa fa-quote-right" style="font-size:48px;color:white"></i></p>
            </div>
          </div>
        </div>
        </div>    </div>
    </div>
    
    <!-- Left and right controls -->
    <a class="carousel-control-prev" href="#demo" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>
    </div>
    <br />
  </div>
  <br />
</div>



<!------------------------------------- footer----------------------------------------------------------->
    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1 class="footer-h1">NEON</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus velit ducimus, enim inventore earum, eligendi nostrum pariatur necessitatibus eius dicta a voluptates sit deleniti autem error eos totam nisi neque voluptates sit deleniti autem error eos totam nisi neque.</p>
            </div>
        <div class="footer-items">
            <h2 class="footer-h2">Quick Links</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Home</li></a>
                <a href=""><li>About Us</li></a>
                <a href=""><li>Contact Us</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Services</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Hotels</li></a>
                <a href=""><li>Paying Guests</li></a>
                <a href=""><li>Car Rentals</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Contact Us</h2>
            <div class="border-footer"></div>
            <ul>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i>XYZ Street, Kolkata</li>
                <li><i class="fa fa-phone" aria-hidden="true"></i>1234567896</li>
                <li><i class="fa fa-envelope" aria-hidden="true"></i>support@neon.com</li>
            </ul>
        </div>
        <div class="social-media">
                <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
        </div>
        </div>
    </div>
    <div class="footer-bottom">
        Copyright &copy; Neon 2020. All rights reserved.
    </div>
</div>








<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>












  </body>
</html>
