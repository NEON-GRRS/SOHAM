<?php
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
	// Load Composer's autoloader
	require 'vendor/autoload.php';
	$name="";
	$email="";
	$errors=array();
	$db=mysqli_connect('localhost','root','','neon');
	$mail = new PHPMailer(true);

	if(isset($_POST['signup'])) {
		
		$password = $_POST['password'];
		$email = $_POST['email'];
		$name = $_POST['name'];
		
		$mobno = $_POST['mobno'];
		/*if(empty($dob)){
			array_push($errors, "DOb is required");
		}

		if(empty($password)){
			array_push($errors, "Password is required");
		}

		if(empty($name)){
			array_push($errors, "Full name is required");
		}

		if(empty($email)){
			array_push($errors, "Email is required");
		}

		if(empty($mobno)){
			array_push($errors, "Mobile No. is required");
		}*/

		$secretKey="6LeVOvIUAAAAACqDpG_6xI7YJgX1Y63YFl1z0xAz";
		$responsekey=$_POST['g-recaptcha-response'];
		$UserIP= $_SERVER['REMOTE_ADDR'];
		$url="https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$responsekey&remoteip=$UserIP";
			
		$response= file_get_contents($url);

		$response=json_decode($response);


		if(count($errors)==0){
		
		if($response->success){
			 $otp = rand(100000,999999);
			 

			 
		$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'itmegadevelopers@gmail.com';                     // SMTP username
    $mail->Password   = 'gbrgrkss';                               // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('itmegadevelopers@gmail.com', 'Neon Booking');
    $mail->addAddress($email,$name);     // Add a recipient
   
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Email Verification';
    $mail->Body    = 'Your OTP for Email Verification'.$otp;
    /*$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';*/

    $mail->send();

			/*$form_data = array(

							'name' => $name,
							'email'=> $email,
							'dob'=> $dob,
							'password' => $password,
							'mobno'=> $mobno,
							'otp' => $otp

			);

			$str = http_build_query($form_data);

			$ch=curl_init();
			curl_setopt($ch, CURLOPT_URL, "http://localhost/test/otp_verify.php");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $str);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$output =curl_exec($ch);
			curl_close($ch);
			//echo $output;*/
			// Store the cipher method 
			$ciphering = "AES-128-CTR"; 
  
			// Use OpenSSl Encryption method 
			$iv_length = openssl_cipher_iv_length($ciphering); 
			$options = 0; 
  
			// Non-NULL Initialization Vector for encryption 
			$encryption_iv = '1234567891011121'; 
  
			// Store the encryption key 
				$encryption_key = "neon"; 
			$encryption = openssl_encrypt($otp, $ciphering, 
            $encryption_key, $options, $encryption_iv); 
		
			header('location:otp.php?name='.$name.'&email='.$email.'&password='.$password.'&mobno='.$mobno.'&otp='.$encryption);
			}

			else {
			echo '<script type="text/javascript">alert("Invalid captcha, please try again"); 
		</script>';
		}

		}
	
	}





?>