<div class="container">
    <div class="modal" id="mymodel">
      <div class="modal-dialog ">
        
        <div class="modal-content">
                <div class= "modal-header">
                    <button type="button" class="close" data-dismiss="modal"> &times;</button>
                </div>
        
            <div class="modal-body">
         
        
                      <center><h3 class="text-primary">Login</h3></center>
                      <center><p style="font-size:20px">Login Using Social accounts</p></center> 

            
                      <center>
                         <label><a href="#" class="fa fa-facebook"></a>
                          <a href="#" class="fa fa-twitter"></a>
                          <a href="#" class="fa fa-google"></a></label>
                      </center>
            
                           &nbsp;&nbsp;&nbsp;
                      <center><p style="font-size:20px">or</p></center> 
          
                    <form id="mylogin" method="post" action="aboutus.php">
                       
                      <div class="form-group">
                        <input type="email" name="uemail" placeholder="Email" class="form-control" required />

                      </div>
                      <div class="form-group">
                         <input type="password" name="upassword" placeholder="Password" class="form-control" required />

                      </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <div class="checkbox">
                         <label><input type="checkbox" value="">Remember me</label>
                          &nbsp;&nbsp;

                       <a href="#" class="btn btn-link">Forget password?</a> 
                       </div>
                      <div class="modal-footer justify-content-center">
                       <input type="submit" class="btn btn-success" name="login" value="Login">
                      </div>
            
                    </form>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            </div>
        </div>
            </div>
          


          </div>

      </div>

  




<div class="container">
    <div class="modal" id="mymodel1">
      <div class="modal-dialog ">
        
        <div class="modal-content">
          <div class= "modal-header">
          <button type="button" class="close" data-dismiss="modal"> &times;</button>
        </div>
        
            <div class="modal-body">

              <center><h3 class="text-primary">Signup</h3></center>
              <center><p style="font-size:20px">Create your account</p></center> 

              

            <form id="mysignup" method="post" action="aboutus.php">
              <div class="form-group">
                <input type="text" name="name" placeholder="Full name" class="form-control" required />

              </div>
              
              <div class="form-group">
                <input type="email" name="email" placeholder="Email" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="password" name="password" placeholder="Password" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="text" name="mobno" placeholder="Mobile No" class="form-control" required />

              </div>
             
                <div class="form-group">

                <input type="date" name="dob" placeholder="DoB(dd\mm\yy)" class="form-control" required />

              </div>

          

              <center><div class="g-recaptcha" data-sitekey="6LeVOvIUAAAAAK_9Pzhoa-KkS2XzQjcz1gUJDFIB" required>
          
             </div></center>
              <div class="modal-footer justify-content-center">
              <input type="submit" class="btn btn-danger"  name="signup" value="Signup">
            </div>
            </form>
            
          </div>
            </div>
          


          </div>
        


        </div>


      </div>

  
      

  </div>