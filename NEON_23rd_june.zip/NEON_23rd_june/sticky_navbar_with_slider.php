
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Sticky nav</title>
   <link rel="stylesheet" href="css/style1.css">
  <link rel="stylesheet" href="css/navbar.css">
  <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/aboutus.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  
    <link rel="stylesheet" href="footer.css">
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>



<!--<style type="text/css">

	#slider {
	overflow: hidden;
}

		  
#slider figure {
	position: relative;
	width: 500%;
	margin: 0;
	left: 0;
	animation: 20s slider infinite;
}
#slider figure img {
	width: 20%;
	float: left;
}

@keyframes slider {
	0% {
		left: 0;
	}
	20% {
		left: 0;
	}
	25% {
		left: -100%;
	}
	45% {
		left: -100%;
	}
	50% {
		left: -200%;
	}
	70% {
		left: -200%;
	}
	75% {
		left: -300%;
	}
	95% {
		left: -300%;
	}
	100% {
		left: -400%;
	}

}
</style>-->
	
<style type="text/css">
  
.hotel-margin{

margin-top: 130px;
padding: 10px;


}



</style>



</head>
<body>
  



<div class="bgimg">
      <nav class="navbar navbar-expand-md navbar-custom bg-dark navbar-dark  fixed-top">
       <!-- Brand -->
        <a class="navbar-brand" href="#"><img src="image/img11.jfif" alt="logo" width="70px"></a>

       <!-- Toggler/collapsibe Button -->
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
       </button>

        <!-- Navbar links -->
       <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <?php session_start();
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="home.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">Home</a>';
            }
            else
            {
               echo '<a class="nav-link" href="home.php">Home</a>';
            }
            ?>
           </li>
            <li class="nav-item">
              <?php
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="aboutus.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">About Us</a>';
            }
            else
            {
               echo '<a class="nav-link" href="aboutus.php">About us</a>';
            }
            ?>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Booking History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Gallery</a>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Top Destinations
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Kolkata</a>
              <a class="dropdown-item" href="#">Asansol</a>
              <a class="dropdown-item" href="#">bhubaneswar</a>
            </div>
          </li>
          
          <?php 
          if(!isset($_SESSION['name']) && !isset($_SESSION['email'])){
            echo'<li class="nav-item dropdown">

            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Login/Signup
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#" data-target="#mymodel1" data-toggle="modal">Sign Up</a>
              <a class="dropdown-item" href="#" data-target="#mymodel" data-toggle="modal">Login</a>
              
            </div>
            </li>';
          }
          else
          {
          }
           ?>
          
             <li class="nav-item dropdown">
                 <?php
                  
                    if(isset($_SESSION['name']) && isset($_SESSION['email']))
                    {
                       echo '<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                            Your Account
                             </a>';
                              echo '<div class="dropdown-menu">';
                               echo '<a class="dropdown-item" href="user_profile.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">'.$_SESSION['name'].'</a>';
                                  echo '<a class="dropdown-item" href="logout.php?logout">Logout</a>';

              
                                   echo '</div>';
                    }
                 
             
                    ?>
          </li>
          <!--<li class="nav-item mgr-autos" >
            <a class="nav-link" href="#">Log in</a>
          </li>-->
           
      </ul>
              
    </div>
    </nav>
  
</div>



































     <div class="hotel-margin">

	<div class="abc">
		<a href="#"  class="logo">ITC ROYAL</a>
		<ul class="nav-custom">
			<li><a href="#overview">Overview</a></li>
			<li><a href="#rooms">Rooms</a></li>
			<li><a href="#gallery">Gallery</a></li>
			<li><a href="#location">Location</a></li>
			<li><a href="#amenities">Amenities</a></li>
			<li><a href="#policies">Policies</a></li>
			<li><a href="#reviews">Reviews</a></li>
			</ul>
	</div>
</div>
     <div class="banner-area" id="overview">



     	<!--<div id="slider">
		<figure>
			<img src="img1.jpg">
			<img src="img2.jpg">
			<img src="img3.jpg">
			<img src="img4.jpg">
			<img src="img5.jpg">
		</figure>
	</div>-->


	<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="image/img1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="image/img2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="image/img3.jpg" alt="Third slide">
    </div>
<div class="carousel-item">
      <img class="d-block w-100" src="image/img4.jpg" alt="Fourth slide">
   


  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>





     </div>
     
     <div class="rooms-area" id="rooms">
     	<div class="text-part">
     	<h1>Rooms area</h1>
     	<p>We've created a sample About Us template designed to work well for virtually any online store, blog, or website. Just fill in the brackets with your company's information and you'll have a professional About Us page written in minutes. If you want to put a personal touch on your page (which we highly recommend), check out the About Us examples below the template.</p>
     	</div>
     </div>
     <div class="gallery-area" id="gallery">
     	<div class="text-part">
     	<h1>Gallery area</h1>
     	<p>We've created a sample About Us template designed to work well for virtually any online store, blog, or website. Just fill in the brackets with your company's information and you'll have a professional About Us page written in minutes. If you want to put a personal touch on your page (which we highly recommend), check out the About Us examples below the template.</p>
     	</div>
     </div>
     <div class="location-area" id="location">
     	<div class="text-part">
     	<h1>location area</h1>
     	<p>We've created a sample About Us template designed to work well for virtually any online store, blog, or website. Just fill in the brackets with your company's information and you'll have a professional About Us page written in minutes. If you want to put a personal touch on your page (which we highly recommend), check out the About Us examples below the template.</p>
     	</div>
     </div>
     <div class="amenities-area" id="amenities">
     	<div class="text-part">
     	<h1>Amenities area</h1>
     	<p>We've created a sample About Us template designed to work well for virtually any online store, blog, or website. Just fill in the brackets with your company's information and you'll have a professional About Us page written in minutes. If you want to put a personal touch on your page (which we highly recommend), check out the About Us examples below the template.</p>
     	</div>
     </div>
     <div class="policies-area" id="policies">
     	<div class="text-part">
     	<h1>Policies area</h1>
     	<p>We've created a sample About Us template designed to work well for virtually any online store, blog, or website. Just fill in the brackets with your company's information and you'll have a professional About Us page written in minutes. If you want to put a personal touch on your page (which we highly recommend), check out the About Us examples below the template.</p>
     	</div>
     </div>
     <div class="reviews-area" id="reviews">
     	<div class="text-part">
     	<h1>Reviews area</h1>
     	<p>We've created a sample About Us template designed to work well for virtually any online store, blog, or website. Just fill in the brackets with your company's information and you'll have a professional About Us page written in minutes. If you want to put a personal touch on your page (which we highly recommend), check out the About Us examples below the template.</p>
     	</div>
     </div>
















<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>














</body>
</html>