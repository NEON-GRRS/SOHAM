
<?php 
    session_start();
    if(isset($_GET['logout']))
    {
        session_destroy();


    	$loggedout="out";   
    	
        header('location:home.php?logout='.$loggedout);

    }
 
?>