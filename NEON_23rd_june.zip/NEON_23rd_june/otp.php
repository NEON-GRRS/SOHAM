<?php include('otp_verify.php'); ?>
<html>
<head>
	<!-- Meta tags -->
      <meta charset = "utf-8">
      <meta name = "viewport" content = "width = device-width, initial-scale = 1, shrink-to-fit = no">
      
      <!-- Bootstrap CSS -->
      <link rel = "stylesheet" 
         href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
         integrity = "sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" 
         crossorigin = "anonymous">
<style type="text/css">
	.otp-form{
  width: 400px;
  background: rgb(0, 0, 0); 
  background: rgba(255, 255, 255, 0.7); 
  height:400px;
  padding: 80px 40px ;
  
  border-radius: 10px;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%,-50%);

}
.error{
    width: 90%;
    margin: 0px auto;
    padding: 1px;
    border: 1px solid #a94442;
    color: #a94442;
    background: #f2dede;
    border-radius: 2px;
    text-align: left;
}





</style>






</head>
<body>
	<div class ="container">
		
	<form method="post" class="otp-form">
		<center><h3>Otp Verification</h3>
		<h6>Verify your email address</h6></center>
    <?php include('errors.php'); ?>
	<div class="form-group">
	<input type="number" class = "form-control" name="otp_submit" placeholder="Enter Otp">
	
	</div>
	<center><input type="submit" class = "btn btn-primary" name="submit_otp" class="signupbtn" value="Sign up"></center>

</form>
</div>


<!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src = "https://code.jquery.com/jquery-3.3.1.slim.min.js" 
         integrity = "sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
         crossorigin = "anonymous">
      </script>
      
      <script src = "https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" 
         integrity = "sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" 
         crossorigin = "anonymous">
      </script>
      
      <script src = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" 
         integrity = "sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" 
         crossorigin = "anonymous">
      </script>


</body>
</html>