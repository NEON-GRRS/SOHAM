<?php

$uemail="";
$upassword="";
$errors=array();
$db=mysqli_connect('localhost','root','','neon');


if(isset($_POST['login']))
{
	
	
		$uemail=$_POST['uemail'];
		$upassword=$_POST['upassword'];
		$query="SELECT * FROM registration WHERE email='$uemail' AND password =
		'$upassword'";
		$result=mysqli_query($db,$query);
		$row= mysqli_fetch_array($result);
		if($row>0){
			session_start();
			$_SESSION['name']=$row['name'];
			$_SESSION['email']=$row['email'];

			$hotel_id=$_REQUEST['hotel_id'];
  			$dest=$_REQUEST['dest'];
  			$checkindate=$_REQUEST['checkindate'];
  			$checkoutdate=$_REQUEST['checkoutdate'];
  			$noofbed=$_REQUEST['noofbed'];

			//header('location:index_updated.php?name='.$row['name'].'&email='.$row['email']);
			//header('location:hotel_description.php?hotel_id='.$hotel_id.'&dest='.$dest.'&name='.$_SESSION['name'].'&email='.$_SESSION['email'].'&checkindate='.$checkindate.'&checkoutdate='.$checkoutdate.'&noofbed='.$noofbed);
  			header('location:hotel_description.php');
			echo'<script type="text/javascript">alert("Login SuccessFull");</script>';

		}
		else
		{	
			//array_push($errors, "Invalid username/password");
			echo'<script type="text/javascript">alert("Invalid email/password");</script>';

		}
	
}
?>