<?php


session_start();
		$email=$_SESSION['email'];
		$hotel_id=$_SESSION['hotel_id'];
		$room_id=$_SESSION['room_id'];
		$checkindate=$_SESSION['checkindate'];
		$checkoutdate=$_SESSION['checkoutdate'];
		$noofbed=$_SESSION['noofbed'];

		$hotel_name=$_SESSION['hotel_name'];
		$hotel_loc=$_SESSION['hotel_loc'];
        $hotel_add=$_SESSION['hotel_add'];
        $hotel_pic=$_SESSION['hotel_pic'];

        $room_price=$_SESSION['room_price'];
        $room_type=$_SESSION['room_type'];
        $room_capacity=$_SESSION['room_capacity'];
        $room_logo= $_SESSION['room_logo'];

        $user_name=$_SESSION['user_name'];
        $user_mobno=$_SESSION['user_mobno'];


        if(isset($_REQUEST['car_type']) && isset($_REQUEST['car_cost'])){
        	$car_cost=$_REQUEST['car_cost'];
        	$car_type=$_REQUEST['car_type'];
        }
        else{
        	$car_cost = 0;
        	$car_type = "You doesn't have any plan";
        }
        $total_price=$room_price+$car_cost;

        /*if(isset($_REQUEST['car_type']) && isset($_REQUEST['car_cost'])){
        	$car_cost=$_REQUEST['car_cost'];
        	$car_type=$_REQUEST['car_type'];
        	$total_price=$room_price+$car_cost;
        	//echo $car_type;
        	//echo $car_cost;
        }
        else
        {
        	$total_price=$room_price;
        }*/
        
        /*echo $hotel_name;
        echo $room_type;
        echo $room_price;
        echo $total_price;*/

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/about.css">
  <link rel="stylesheet" href="css/navbar.css">
  <link rel="stylesheet" href="css/footer.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  
    <link rel="stylesheet" href="footer.css">
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>
     <script src='https://kit.fontawesome.com/a076d05399.js'></script>
     <style type="text/css">
  

     </style>
     <script src='https://kit.fontawesome.com/a076d05399.js'></script>
</head>
<body style="background: rgb(41,206,232);
       background: linear-gradient(90deg, rgba(41,206,232,1) 0%, rgba(214,242,251,1) 33%, rgba(251,250,255,1) 50%, rgba(225,245,252,1) 66%, rgba(41,206,232,1) 100%, rgba(0,212,255,1) 100%);">
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top" style="border:2px solid;border-radius:12px;">
      <a href="#"  class="logo" style="font-size: 2em;"> Neon Booking Service</a>  
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleSubNavbar">
            <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="collapsibleSubNavbar" style="text-align: right;">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="#scheme">My Profile</a>
          </li>
        </ul>
      </div>
    </nav> <br /><br />
	<div class="imgdiv" align="center">
		<img src="image/cart.png"style="width: 90px;height: 90px; clip-path: circle(50% at 50% 50%);"><br />
		<h4 class="h4">Your Booking Summary</h4>
	</div><br /><br />
	<div class="hotel" style="border: 1px solid white;border-radius: 10px;background: rgb(41,206,232);
       background: linear-gradient(90deg, rgba(41,206,232,1) 0%, rgba(214,242,251,1) 33%, rgba(251,250,255,1) 50%, rgba(225,245,252,1) 66%, rgba(41,206,232,1) 100%, rgba(0,212,255,1) 100%);height: 275px;">
		<img src="<?php echo $hotel_pic;?>" align="left">
		<img src="<?php echo $room_logo ;?>" align="right">
		<h6 class="h6" align="center" style="padding-top:100px; "> Your booking For</h6>
		<h1 class="h1" style="color: red;" align="center" ><?php echo $hotel_name ?></h1>
		
	</div>
	<br /><br />
   <div class="container outer">
		<div class="row">
			<div class="column" >
				<h5>Customer details</h5>
		       <div class="card" style="padding-left: 25px;padding-top: 10px;padding-right: 25px;">
		       	<table class="table table-striped">
		       		<tr>
		       			<th>USER Name:</th><td><?php echo $user_name?></td>
		       		</tr>
		       		<tr>
		       			<th>User Contact</th><td><?php echo$user_mobno?></td>
		       		</tr>
		       		<tr>
		       			<th>User EMAIL:</th><td><?php echo$email ?></td>
		       		</tr>
		       	</table>
		       </div>
			</div>
			<div class="column" style="padding-left: 15px;">
				<h5>Booking details</h5>
		       <div class="card" style="padding-left: 25px;padding-top: 10px;padding-right: 25px;">
			       	<table class="table table-striped">
			       		<tr>
			       			<th>Check-in Date:</th><td><?php echo $checkindate ?></td>
			       		</tr>
			       		<tr>
			       			<th>Check-out Date:</th><td><?php echo $checkoutdate ?></td>
			       		</tr>
			       		<tr>
			       			<th>Room Type:</th><td><?php echo $room_type ?></td>
			       		</tr>
			       		<tr>
			       			<th>Room Capacity:</th><td><?php echo $room_capacity ?></td>
			       		</tr>
			       		<tr>
			       			<th>No of Bed Required:</th><td><?php echo $noofbed ?></td>
			       		</tr>
			       		<tr>
			       			<th style="color: red">Room Rent:</th><td style="color: red"><?php echo $room_price ?></td>
			       		</tr>
			       	</table>
		       </div>
			</div>
			<div class="column" style="padding-left: 10px;">
				<h5>Car Rental Details</h5>
		       <div class="card" style="padding-left: 25px;padding-top: 10px;padding-right: 25px;">
		       	<table class="table table-striped">
		       		<tr>
		       			<th>Car Plan Type:</th><td><?php echo $car_type ?></td>
		       		</tr>
		       		<tr>
		       			<th>Available From:</th><td><?php echo$checkindate ?></td>
		       		</tr>
		       		<tr>
		       			<th>Available TO:</th><td><?php echo$checkoutdate ?></td>
		       		</tr>
		       		<tr>
		       			<th style="color: red">Car Rental Cost:_</th><td style="color: red"><?php echo$car_cost ?></td>
		       		</tr>
		       	</table>
		       </div>
			</div>
		</div>
		<div class="row">
			<div class="center">
				<div class="column">
					<h3 class="h3" style="color: red"> Payment Details</h3>
					<h6 class="h6"> Please check all the details carefully... </h6>
					<div class="card" style="padding-left: 25px;padding-top: 10px;padding-right: 25px;">
						<form>
							<table class="table table-striped">
								<tr >
									<th>Room Rent:</th><td><?php echo $room_price ?></td>
								</tr>
								<tr >
									<th>Car Rental Cost:</th><td><?php echo $car_cost ?></td>
								</tr>
								<tr style="color :red">
									<th>Total Cost:</th><td><?php echo $total_price ?></td>
								</tr>
							</table>
							<h6 class="h6" style="color: red"> <input type="checkbox" name="room_ok" required >&nbsp;All Data Are Correct as It Stated Above</h6><br />
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input type="submit" value="MakePayment" class="btn btn-primary" ><br />
							<br />
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
<!---------------------------------------- footer--------------------------------------------------------------->
  <br />
    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1 class="footer-h1">NEON</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus velit ducimus, enim inventore earum, eligendi nostrum pariatur necessitatibus eius dicta a voluptates sit deleniti autem error eos totam nisi neque voluptates sit deleniti autem error eos totam nisi neque.</p>
            </div>
        <div class="footer-items">
            <h2 class="footer-h2">Quick Links</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Home</li></a>
                <a href=""><li>About Us</li></a>
                <a href=""><li>Contact Us</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Services</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Hotels</li></a>
                <a href=""><li>Paying Guests</li></a>
                <a href=""><li>Car Rentals</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Contact Us</h2>
            <div class="border-footer"></div>
            <ul>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i>XYZ Street, Kolkata</li>
                <li><i class="fa fa-phone" aria-hidden="true"></i>1234567896</li>
                <li><i class="fa fa-envelope" aria-hidden="true"></i>support@neon.com</li>
            </ul>
        </div>
        <div class="social-media">
                <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
        </div>
        </div>
    </div>
    <div class="footer-bottom">
        Copyright &copy; Neon 2020. All rights reserved.
    </div>
</div>





<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>