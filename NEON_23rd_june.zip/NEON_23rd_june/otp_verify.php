<?php
$db=mysqli_connect('localhost','root','','neon');

$errors=array();
	if(isset($_POST['submit_otp'])){

	
		$password = $_REQUEST['password'];
		$email = $_REQUEST['email'];
		$name = $_REQUEST['name'];
		
		$mobno = $_REQUEST['mobno'];
		$otp=$_REQUEST['otp'];
		$ciphering = "AES-128-CTR";
		// Non-NULL Initialization Vector for decryption 
		$decryption_iv = '1234567891011121'; 
  
        // Store the decryption key 
		$decryption_key = "neon"; 
		$options = 0; 
  		
		// Use openssl_decrypt() function to decrypt the data 
		$otp_d=openssl_decrypt ($otp, $ciphering,  
        $decryption_key, $options, $decryption_iv); 
		
		
		$otp_submit=$_POST['otp_submit'];

		if($otp_d == $otp_submit){
		$sql = "INSERT INTO registration(name,email,password,mobno)
							VALUES ('$name','$email','$password','$mobno') ";
			mysqli_query($db, $sql);
		header("location:home.php");
			
		}
		else
		{
			array_push($errors, "Invalid OTP");
		//header("location:home.php");
			
		}

	}


?>