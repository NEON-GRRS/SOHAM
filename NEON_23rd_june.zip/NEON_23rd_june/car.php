<?php include('register.php');?>
<?php include('process.php');?>
<?php include('database_connection.php'); ?>
<?php

if(isset($_REQUEST['hotel_id'])){

  $hotel_id=$_REQUEST['hotel_id'];

}

session_start();
if(isset($_POST['premium']))
{
  $carquery="SELECT * FROM car WHERE car_id=
          'car01'";
        $statement = $connect->prepare($carquery);
        $statement->execute();
        $result = $statement->fetchAll();
        $total_row = $statement->rowCount();
        foreach ($result as $row) {
          $car_type= $row['car_type'];
          
          $car_cost=$row['car_cost'];
          
        }
        // echo $car_type;
        //echo $car_cost;
        $_SESSION['car_type']=$car_type;
        $_SESSION['car_cost']=$car_cost;

       

}
if(isset($_POST['regular']))
{
  $carquery="SELECT * FROM car WHERE car_id=
          'car02'";
        $statement = $connect->prepare($carquery);
        $statement->execute();
        $result = $statement->fetchAll();
        $total_row = $statement->rowCount();
        foreach ($result as $row) {
          $car_type= $row['car_type'];
          
          $car_cost=$row['car_cost'];
          
        }
         /*echo $car_type;
        echo $car_cost;*/
        $_SESSION['car_type']=$car_type;
        $_SESSION['car_cost']=$car_cost;
       

}
if(isset($_POST['easy']))
{
  $carquery="SELECT * FROM car WHERE car_id=
          'car03'";
        $statement = $connect->prepare($carquery);
        $statement->execute();
        $result = $statement->fetchAll();
        $total_row = $statement->rowCount();
        foreach ($result as $row) {
          $car_type= $row['car_type'];
          
          $car_cost=$row['car_cost'];
          
        }
        /* echo $car_type;
        echo $car_cost;*/
       /* $_SESSION['car_type']=$car_type;
        $_SESSION['car_cost']=$car_cost;*/
       

}
$email=$_SESSION['email'];
    $hotel_id=$_SESSION['hotel_id'];
    $room_id=$_SESSION['room_id'];
    $checkindate=$_SESSION['checkindate'];
    $checkoutdate=$_SESSION['checkoutdate'];
    $noofbed=$_SESSION['noofbed'];













































?>


   


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/about.css">
  <link rel="stylesheet" href="css/navbar.css">
  <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/car.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  
    <link rel="stylesheet" href="footer.css">
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>
     <script src='https://kit.fontawesome.com/a076d05399.js'></script>
     <style type="text/css">
       
      .scheme_style{
    padding-top: 30px;
    border: 2px solid white;
    border-radius: 25px;
    background-color: transparent;
    opacity: 1;

  }
  .sec1{
  /*padding-left: 55px;
  padding-right: 35px;*/
  background: linear-gradient(to bottom, #ffffff -4%, #000000 100%);
  border:1px solid white;
  border-radius:15px;
  box-shadow: 5px 5px 10px #550985;

}

.sec1_1{
  padding-left: 35px;
  padding-right: 35px;
}
.sec1_2{
  padding-left: 35px;
  padding-right: 35px;
}
.sec1_3{
  padding-left: 75px;
}
.sec1_4{
  padding-left: 130px;
}
 .sec2{
  /*padding-left: 55px;
  padding-right: 35px;*/
  background: linear-gradient(to bottom, #ffffff 0%, #6600cc 100%);
  border:1px solid white;
  border-radius:15px;
  box-shadow: 5px 5px 10px #550985;

}

.sec2_1{
  padding-left: 35px;
  padding-right: 35px;
}
.sec2_2{
  padding-left: 35px;
  padding-right: 35px;
}
.sec2_3{
  padding-left: 50px;
}
.sec2_4{
  padding-left: 100px;
}
 .sec3{
  /*padding-left: 55px;
  padding-right: 35px;*/
  background: linear-gradient(to bottom, #ffffff 0%,   #000066 100%);
  border:1px solid white;
  border-radius:15px;
  box-shadow: 5px 5px 10px #550985;

}

.sec3_1{
  padding-left: 35px;
  padding-right: 35px;
}
.sec3_2{
  padding-left: 35px;
  padding-right: 35px;
}
.sec3_4{
  paddin
}
#premium{
  border:1px solid white;
  border-radius: 12px;
  height:275px;
  background-color: white;
}
#regular{
  border:1px solid white;
  border-radius: 12px;
  height:275px;
    background-color: white;
}
#easy{
  border:1px solid white;
  border-radius: 12px;
  height:275px;
  background-color: white;
}

     </style>
  </head>
  <body>
    <!------------------------------navbar------------------------------------>
  <div class="bgimg">
      <nav class="navbar navbar-expand-md navbar-custom bg-dark navbar-dark fixwd-top ">
       <!-- Brand -->
        <a class="navbar-brand" href="#"><img src="image/img11.jfif" alt="logo" width="70px"></a>

       <!-- Toggler/collapsibe Button -->
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
       </button>

        <!-- Navbar links -->
       <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <?php 
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="home.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">Home</a>';
            }
            else
            {
               echo '<a class="nav-link" href="home.php">Home</a>';
            }
            ?>
           </li>
            <li class="nav-item">
              <?php
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="aboutus.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">About Us</a>';
            }
            else
            {
               echo '<a class="nav-link" href="aboutus.php">About us</a>';
            }
            ?>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Booking History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Gallery</a>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Top Destinations
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Kolkata</a>
              <a class="dropdown-item" href="#">Asansol</a>
              <a class="dropdown-item" href="#">bhubaneswar</a>
            </div>
          </li>
          
          <?php 
          if(!isset($_SESSION['name']) && !isset($_SESSION['email'])){
            echo'<li class="nav-item dropdown">

            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Login/Signup
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#" data-target="#mymodel1" data-toggle="modal">Sign Up</a>
              <a class="dropdown-item" href="#" data-target="#mymodel" data-toggle="modal">Login</a>
              
            </div>
            </li>';
          }
          else
          {
          }
           ?>
          
             <li class="nav-item dropdown">
                 <?php
                  
                    if(isset($_SESSION['name']) && isset($_SESSION['email']))
                    {
                       echo '<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                            Your Account
                             </a>';
                              echo '<div class="dropdown-menu">';
                               echo '<a class="dropdown-item" href="user_profile.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">'.$_SESSION['name'].'</a>';
                                  echo '<a class="dropdown-item" href="logout.php?logout">Logout</a>';

              
                                   echo '</div>';
                    }
                 
             
                    ?>
          </li>
          <!--<li class="nav-item mgr-autos" >
            <a class="nav-link" href="#">Log in</a>
          </li>-->
           
      </ul>
              
    </div>
    </nav>
  
</div>

<!--------navbar end------>
<!---------------------------------------- Login / SIgn up -------------------------------------->

<!---------------------------------------- Login / SIgn up -------------------------------------->
<div class="container">
    <div class="modal" id="mymodel">
      <div class="modal-dialog ">
        
        <div class="modal-content">
                <div class= "modal-header">
                    <button type="button" class="close" data-dismiss="modal"> &times;</button>
                </div>
        
            <div class="modal-body">
         
        
                      <center><h3 class="text-primary">Login</h3></center>
                      <center><p style="font-size:20px">Login Using Social accounts</p></center> 

            
                      <center>
                         <label><a href="#" class="fa fa-facebook"></a>
                          <a href="#" class="fa fa-twitter"></a>
                          <a href="#" class="fa fa-google"></a></label>
                      </center>
            
                           &nbsp;&nbsp;&nbsp;
                      <center><p style="font-size:20px">or</p></center> 
          
                    <form id="mylogin" method="post" action="aboutus.php">
                       
                      <div class="form-group">
                        <input type="email" name="uemail" placeholder="Email" class="form-control" required />

                      </div>
                      <div class="form-group">
                         <input type="password" name="upassword" placeholder="Password" class="form-control" required />

                      </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <div class="checkbox">
                         <label><input type="checkbox" value="">Remember me</label>
                          &nbsp;&nbsp;

                       <a href="#" class="btn btn-link">Forget password?</a> 
                       </div>
                      <div class="modal-footer justify-content-center">
                       <input type="submit" class="btn btn-success" name="login" value="Login">
                      </div>
            
                    </form>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            </div>
        </div>
            </div>
          


          </div>

      </div>

  




<div class="container">
    <div class="modal" id="mymodel1">
      <div class="modal-dialog ">
        
        <div class="modal-content">
          <div class= "modal-header">
          <button type="button" class="close" data-dismiss="modal"> &times;</button>
        </div>
        
            <div class="modal-body">

              <center><h3 class="text-primary">Signup</h3></center>
              <center><p style="font-size:20px">Create your account</p></center> 

              

            <form id="mysignup" method="post" action="aboutus.php">
              <div class="form-group">
                <input type="text" name="name" placeholder="Full name" class="form-control" required />

              </div>
              
              <div class="form-group">
                <input type="email" name="email" placeholder="Email" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="password" name="password" placeholder="Password" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="text" name="mobno" placeholder="Mobile No" class="form-control" required />

              </div>
             
           
          

              <center><div class="g-recaptcha" data-sitekey="6LeVOvIUAAAAAK_9Pzhoa-KkS2XzQjcz1gUJDFIB" required>
          
             </div></center>
              <div class="modal-footer justify-content-center">
              <input type="submit" class="btn btn-danger"  name="signup" value="Signup">
            </div>
            </form>
            
          </div>
            </div>
          


          </div>
        


        </div>


      </div>

  
      

  </div>


<!---------------------------------------- description -------------------------------------->
<div class="outer">
  <br />
  <div class="main_box container-fluid" data-spy="scroll" data-target=".navbar" data-offset="50" >
    <br />
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top" style="border:2px solid;border-radius:12px;">
      <a href="#"  class="logo" style="font-size: 2em;"> Neon Car Rental Service</a>  
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleSubNavbar">
            <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="collapsibleSubNavbar" style="text-align: right;">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="#scheme">Scheme</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#about">About The services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#faq">FAQs</a>
          </li>
        </ul>
      </div>
    </nav> 
    <br />
    <div id="scheme" class="container-fluid scheme_style" style="padding-top:30px;padding-bottom:30px;">
      <h1 align="center">Schemes:</h1><br />
      <div class="row">
        <div class="column" style="padding-left: 50px;" ><form method="post" action="car.php">
          <div class="sec1">
            <img src="image/cccc.jfif" style="border: 1px solid ; border-radius: 10px; width:100%;">
            <div class="sec1_1">
              <h3 align="center">Premium Booking</h3>
              <ul>
                <li><i class='far fa-calendar-check'></i>Premium sedan class car </li>
                <li><i class='far fa-calendar-check'></i>Prior Booking</li>
                <li><i class='far fa-calendar-check'></i>Secure</li>
              </ul>
            </div>
            <div class="sec1_2">
              <h5  align="center" style="color: white">Know Your Ride</h5>
              <ul>
                <li><i class='fas fa-car'></i>comfort <i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i> </li>
                <li><i class='fas fa-id-card-alt'></i>Security<i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i></li>
                <li><i class='fas fa-handshake'></i>Service<i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i></li>
                <li><i class='fa fa-inr'></i>Cost&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i></li>
              </ul>
            </div>  
            <div class="sec1_3">
              <button type="button"  class="btn btn-primary" align="center" style="width:190px;" onClick="document.getElementById('premium').scrollIntoView();" > More info. </button><br />
            </div><br />
            <div class="sec1_4">
              <input type="submit" value="choose" name="premium" class="btn btn-primary"> 
            </div><br />
          </div>
        </form>
        </div>
        <div class="column" style="padding-left: 70px" ><form method="post" action="car.php">
          <div class="sec2">
            <img src="image/ccc.jfif" style="border: 1px solid ; border-radius: 10px; width:100%;height:200px;">
            <div class="sec2_1">
              <h3 align="center">Regular Booking</h3>
              <ul>
                <li><i class='far fa-calendar-check'></i>Fit for all Day </li>
                <li><i class='far fa-calendar-check'></i>Prior Booking</li>
                <li><i class='far fa-calendar-check'></i>Secure</li>
              </ul>
            </div>
            <div class="sec2_2">
              <h5  align="center" style="color: white">Know Your Ride</h5>
              <ul>
                <li><i class='fas fa-car'></i>comfort <i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='far fa-star'></i> </li>
                <li><i class='fas fa-id-card-alt'></i>Security<i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i></li>
                <li><i class='fas fa-handshake'></i>Service<i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i></li>
                 <li><i class='fa fa-inr'></i>Cost&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='far fa-star'></i><i class='far fa-star'></i></li>
              </ul>
              <div class="sec2_3">
              <button type="button"  class="btn btn-primary" align="center" style="width:190px;" onClick="document.getElementById('regular').scrollIntoView();" > More info. </button><br />
            </div><br />
            <div class="sec2_4">
              <input type="submit" value="choose" name="regular" class="btn btn-primary">
            </div><br />
            </div>            
          </div>
        </form>
        </div>
         <div class="column" style="padding-left: 70px;" ><form method="post" action="car.php">
          <div class="sec3">
            <img src="image/cc.png" style="border: 1px solid ; border-radius: 10px; width:100%;height:200px;">
            <div class="sec3_1">
              <h3 align="center">Easy Booking</h3>
              <ul>
                <li><i class='far fa-calendar-check'></i>Subject of availability </li>
                <li><i class='far fa-calendar-check'></i>Easy offline method</li>
                <li><i class='far fa-calendar-check'></i>Pocket friendly</li>
              </ul>

            </div>
            <div class="sec3_2">
              <h5  align="center" style="color: white">Know Your Ride</h5>
              <ul>
                <li><i class='fas fa-car'></i>comfort <i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='far fa-star'></i><i class='far fa-star'></i> </li>
                <li><i class='fas fa-id-card-alt'></i>Security<i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='far fa-star'></i></li>
                <li><i class='fas fa-handshake'></i>Service<i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='fas fa-star'></i><i class='far fa-star'></i></li>
                 <li><i class='fa fa-inr'></i>Cost&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fas fa-star'></i><i class='far fa-star'></i><i class='far fa-star'></i><i class='far fa-star'></i><i class='far fa-star'></i></li>
              </ul>
              <div class="sec2_3">
              <button type="button"  class="btn btn-primary" align="center" style="width:190px;" onClick="document.getElementById('easy').scrollIntoView();" > More info. </button><br />
            </div><br />
            <div class="sec2_4">
              <input type="submit" value="choose" name="easy" class="btn btn-primary"> 
            </div><br />
            </div>            
          </div>
        </form>
        </div> 
      </div>
   </div>
    <br />
    <div class="row">
      <div class="column" style="width: 65%;padding-left: 50px;">
        <div class="your_details container" style="background-color: white;border:1px solid white;border-radius:20px; padding-top:25px;">
             <div class="heading" style="border:2px solid white;border-radius: 20px;box-shadow: 2px 2px 2px 2px #73a5f5; ">
              <h3 align="center"><i class='fas fa-rupee-sign' style='font-size:35px;color:#4287f5'>&nbsp&nbsp&nbsp</i>Proceed and Check-out</h3>
            </div><br><br>
            <h2 style="font-family: comic-sans"><p>All Set for check-out!!!</p></h2>
            For payment check the below box and continue....<br />
            <?php if(isset($car_type)){ echo'<h5>You choosed'.$car_type.'Booking</h5>';}?>
            <input type="checkbox" name="car_not_need">&nbsp;&nbsp;All the above details are correct...As per consumer's choice</input><br /><br /><?php echo'
            <a class="btn btn-primary" href="payment.php?car_type='.$car_type.'&car_cost='.$car_cost.'">';?>Payment and continue.....</a><br /><br /><br />
          </div>
      </div>
      <div class="column" style="width: 5%"> </div>
      <div class="column" style="width: 30%;padding-right: 50px">
        <div id="faq" class="container-fluid faq_style" style="padding-top:70px;padding-bottom:70px;overflow:scroll;height:330px;">
      <h1>Faq</h1>
      Q<br />A<br />Q<br />A<br />Q<br />A<br />Q<br />A<br />Q<br />A<br />
      Q<br />A<br />Q<br />A<br />Q<br />A<br />Q<br />A<br />Q
     
    </div>
      </div>
    </div>
    <div id="about" class="container-fluid about_style" style="padding-top:70px;padding-bottom:70px">
      <h1>About The services</h1>
      <br />
      <div id="premium">
        <h3 align="center"> Premium Booking</h3></div><br />
      <div id="regular">
        <h3 align="center"> Regular Booking</h3></div><br />
      <div id="easy">
        <h3 align="center">Easy Booking</h3></div><br />
    </div>
    <br />
    
    <br />
    
</div>



<!------------------------------------- footer----------------------------------------------------------->
    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1 class="footer-h1">NEON</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus velit ducimus, enim inventore earum, eligendi nostrum pariatur necessitatibus eius dicta a voluptates sit deleniti autem error eos totam nisi neque voluptates sit deleniti autem error eos totam nisi neque.</p>
            </div>
        <div class="footer-items">
            <h2 class="footer-h2">Quick Links</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Home</li></a>
                <a href=""><li>About Us</li></a>
                <a href=""><li>Contact Us</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Services</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Hotels</li></a>
                <a href=""><li>Paying Guests</li></a>
                <a href=""><li>Car Rentals</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Contact Us</h2>
            <div class="border-footer"></div>
            <ul>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i>XYZ Street, Kolkata</li>
                <li><i class="fa fa-phone" aria-hidden="true"></i>1234567896</li>
                <li><i class="fa fa-envelope" aria-hidden="true"></i>support@neon.com</li>
            </ul>
        </div>
        <div class="social-media">
                <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
        </div>
        </div>
    </div>
    <div class="footer-bottom">
        Copyright &copy; Neon 2020. All rights reserved.
    </div>
</div>








<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>












  </body>
</html>
