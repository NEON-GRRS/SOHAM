<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		#map{
			height: 500px;
			width: 400px;
		}
	</style>
</head>
<body>
	<div id="map"></div>
        <script>
          function initMap() {
            var location ={lat: 22.5797545, lng: 88.4589116};
            var map =new google.maps.Map(document.getElementById("map"),{
                zoom: 3,
                center: location
            });
            var marker =new google.maps.Marker({
                position: location,
                map: map
            });
          }
        </script>
          <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCng70lMiT1nAJjaECBtWEceBpKnJQELXw&callback=initMap"
          type="text/javascript"></script>

</body>
</html>