<?php include('database_connection.php'); ?>
<?php
	session_start();
	/*if(isset($_REQUEST['room_id'])&& isset($_REQUEST['hotel_id'])){

		echo $_REQUEST['room_id'];
		echo $_REQUEST['hotel_id'];*/
		/*echo $_SESSION['name'];
		echo $_SESSION['hotel_id'];
		echo $_SESSION['room_id'];*/
		$email=$_SESSION['email'];
		$hotel_id=$_SESSION['hotel_id'];
		$room_id=$_REQUEST['room_id'];
		$checkindate=$_SESSION['checkindate'];
		$checkoutdate=$_SESSION['checkoutdate'];
		$noofbed=$_SESSION['noofbed'];
		$hotelquery="SELECT * FROM hotel WHERE hotel_id=
          '$hotel_id'";
        $statement = $connect->prepare($hotelquery);
        $statement->execute();
        $result = $statement->fetchAll();
        $total_row = $statement->rowCount();
        foreach ($result as $row) {
          $hotel_name= $row['hotel_name'];
          $hotel_loc=$row['hotel_loc'];
          $hotel_add=$row['hotel_add'];
          $hotel_pic=$row['hotel_pic'];
          
        }
        $_SESSION['hotel_name']=$hotel_name;
        $_SESSION['hotel_loc']=$hotel_loc;
        $_SESSION['hotel_add']=$hotel_add;
        $_SESSION['hotel_pic']=$hotel_pic;
        
        

        

        


        $roomquery="SELECT * FROM room WHERE room_id=
          '$room_id'";
        $statement = $connect->prepare($roomquery);
        $statement->execute();
        $result = $statement->fetchAll();
        $total_row = $statement->rowCount();
        foreach ($result as $row) {
          $room_type= $row['room_type'];
          $room_capacity=$row['room_capacity'];
          $room_price=$row['room_price'];
          $room_logo=$row['room_logo'];
          
        }
        $_SESSION['room_price']=$room_price;
        $_SESSION['room_type']=$room_type;
        $_SESSION['room_capacity']=$room_capacity;
        $_SESSION['room_id']=$room_id;
        $_SESSION['room_logo']=$room_logo;

        $userquery="SELECT * FROM registration WHERE email=
          '$email'";

         $statement = $connect->prepare($userquery);
        $statement->execute();
        $result = $statement->fetchAll();
        $total_row = $statement->rowCount();
        foreach ($result as $row) {
          $user_name= $row['name'];
          $user_mobno=$row['mobno'];
     
        }
        $_SESSION['user_name']=$user_name;
        $_SESSION['user_mobno']=$user_mobno;
      
        $dest=$hotel_loc;
       


	//}
	?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/about.css">
  <link rel="stylesheet" href="css/navbar.css">
  <link rel="stylesheet" href="css/footer.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  
    <link rel="stylesheet" href="footer.css">
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>
     <script src='https://kit.fontawesome.com/a076d05399.js'></script>

     <style type="text/css">
         .navbar-custom{
            background-color: #0062ff;
         }
         .your_details{
            
         }
     </style>
</head>
<body>
	

<!--------------------------------------------confirmation ------------------------------------------>
<div class=" container-fluid confirmation" style="background-color: #ebebeb">
 <div class="upper_div">
<nav class="navbar navbar-expand-sm navbar-custom">

  <a> NEON</a> &nbsp&nbsp&nbsp&nbsp
  <!-- Links -->
  <ul class="navbar-nav">

    <li class="nav-item">
      <?php echo'<a class="nav-link" href="user_profile.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">My Profile</a>';?>

    </li>
    <li class="nav-item">
      <?php echo '<a class="nav-link" href="booking_page.php?dest='.$dest.'&name='.$_SESSION['name'].'&email='.$_SESSION['email'].'&checkindate='.$checkindate.'&checkoutdate='.$checkoutdate.'&noofbed='.$noofbed.'">Seach More@buton to back to the booking page</a>'; ?>
    </li>
  </ul>

</nav>	

 </div>
 <br />
 <div align="center" style="background-color: #ebebeb ;height:200px;width:100%; padding-bottom:15px;">
     <img src="image/tick.jpg" style="clip-path: circle(40% at 50% 50%);"><br><h4 style="color:green;">Thanks for been with Us</h4>
 </div>

 <div class="row">
 	<div class="column" style="width:60%;padding-left:20px;padding-right: 20px;padding-bottom: 10px;">
      <div class="your_details container" style="background-color: white;border:1px solid white;border-radius:20px; padding-top:25px;">
        <div class="heading" style="border:2px solid white;border-radius: 20px;box-shadow: 2px 2px 2px 2px #73a5f5; ">
          <h3 align="center"><i class='far fa-id-card' style='font-size:35px;color:#4287f5'>&nbsp&nbsp&nbsp</i>Consumer Details</h3>
        </div><br><br>
         <div class="card" style="border:1px solid white;padding-left: 120px;">
            <i class='far fa-user' style='font-size: 25px; color:#4287f5'>&nbsp&nbsp&nbsp&nbsp<?php echo $user_name;?></i><br />
            <i class='far fa-envelope' style='font-size: 25px;color:#4287f5'>&nbsp&nbsp&nbsp<?php echo $email;?></i><br />
            <i class='fas fa-phone' style='font-size: 25px;color:#4287f5'>&nbsp&nbsp&nbsp<?php echo $user_mobno;?></i><br />
         </div>
      </div>
      <br><br>
     <div class="service_details container" style="background-color: white;border:1px solid white;border-radius:20px; padding-top:25px;">
            <div class="heading" style="border:2px solid white;border-radius: 20px;box-shadow: 2px 2px 2px 2px #73a5f5; ">
              <h3 align="center"><i class='far fa-handshake' style='font-size:35px;color:#4287f5'>&nbsp&nbsp&nbsp</i>Service Details</h3>
           </div><br><br>
           <div class="row">
            <div class="column" style="padding-left: 35px;">
               <div class="card" style="border:1px solid white;padding-left: 35px; box-shadow: 1px 2px 1px 2px #ebebeb;"><br />
                  <i class='far fa-building' style='font-size: 25px;color:#4287f5'>&nbsp Hotel:</i>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $hotel_name;?><br />
                  <i class='far fa-map' style='font-size: 25px; color:#4287f5'>&nbsp Address</i>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $hotel_add;?><br />
                  <i class='fas fa-bed' style='font-size: 20px;color:#4287f5'>&nbsp Room Type:</i>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $room_type;?><br />
                  <i class='fas fa-home' style='font-size: 20px;color:#4287f5'>&nbsp Capacity:</i>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $room_capacity;?> Person <br />
                  <i class='far fa-calendar-check' style='font-size: 20px;color:#4287f5'>&nbsp Check-in:</i>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $checkindate;?>  <br />
                  <i class='far fa-calendar-check' style='font-size: 20px;color:#4287f5'>&nbsp Check-in:</i>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $checkindate;?>  <br />
               </div>
              </div>
             
             <div class="column">
                <img src="<?php echo $hotel_pic;?>" style=" border:1px solid white;border-radius:50px;padding: 10px 10px 10px 10px; align-self: center; clip-path: circle(30% at 50% 50%);">
             </div>
           </div><br /><br />
      </div><br><br>
  </div>
 	
  <div class="column" style="width:40%;padding-left:20px;padding-right: 20px;padding-bottom: 10px; ">
    <div class="your_details container" style="background-color: white;border:1px solid white;border-radius:20px; padding-top:25px;">
        <div class="heading" style="border:2px solid white;border-radius: 20px;box-shadow: 2px 2px 2px 2px #73a5f5; ">
          <h3 align="center"><i class='fas fa-car' style='font-size:35px;color:#4287f5'>&nbsp&nbsp&nbsp</i>Neon Car Service</h3>
        </div><br><br>
         <h6>take a relaxing ride with us...
            make your trip memorable...
            Feel the comfort with a budget-friendly ride.
         </h6> <br />
         <div class="rules" style="padding-left: 50px;">
           <i class="far fa-check-square" style="font-size:24px">&nbsp;&nbsp;&nbsp;Secure Ride</i>
           <i class="far fa-check-square" style="font-size:24px">&nbsp;&nbsp;&nbsp;No headache at new city</i>
            <i class="far fa-check-square" style="font-size:24px">&nbsp;&nbsp;&nbsp;Always at your service</i>
            <i class="far fa-check-square" style="font-size:24px">&nbsp;&nbsp;&nbsp;Choose from a bouquet of            schemes</i>
         </div><br />

         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp


         <a class="btn btn-primary" href="car.php">Check it out!!!</a>
         <br /><br />
      </div><br /><br />
      <div class="your_details container" style="background-color: white;border:1px solid white;border-radius:20px; padding-top:25px;">
         <div class="heading" style="border:2px solid white;border-radius: 20px;box-shadow: 2px 2px 2px 2px #73a5f5; ">
          <h3 align="center"><i class='fas fa-rupee-sign' style='font-size:35px;color:#4287f5'>&nbsp&nbsp&nbsp</i>Proceed and Check-out</h3>
        </div><br><br>
        <h2 style="font-family: comic-sans"><p>All Set for check-out!!!</p></h2>
        For payment check the below box and continue....<br />
        <input type="checkbox" name="car_not_need">&nbsp;&nbsp;All the above details are correct...As per consumer's choice</input><br /><br />
        <a class="btn btn-primary" href="payment.php">Payment and continue.....</a><br /><br /><br />
      </div>
    <!--div class="payment" style="background-color: white; border:1px solid white;border-radius:10px;padding-top: 18px;">
       <h3 align="center"><i class='fas fa-rupee-sign' style='font-size: 25px;color:#4287f5'></i>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspPayment Structure</h3>
       <i class='fas fa-rupee-sign' style='font-size: 25px;color:#4287f5'>&nbsp&nbsp&nbsp</i><?php echo $room_price;?><br />
    </div-->
  </div>
 </div>
</div>

  <!-------------------------------- footer--------------------------------------------------------------->
  <br />
    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1 class="footer-h1">NEON</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus velit ducimus, enim inventore earum, eligendi nostrum pariatur necessitatibus eius dicta a voluptates sit deleniti autem error eos totam nisi neque voluptates sit deleniti autem error eos totam nisi neque.</p>
            </div>
        <div class="footer-items">
            <h2 class="footer-h2">Quick Links</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Home</li></a>
                <a href=""><li>About Us</li></a>
                <a href=""><li>Contact Us</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Services</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Hotels</li></a>
                <a href=""><li>Paying Guests</li></a>
                <a href=""><li>Car Rentals</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Contact Us</h2>
            <div class="border-footer"></div>
            <ul>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i>XYZ Street, Kolkata</li>
                <li><i class="fa fa-phone" aria-hidden="true"></i>1234567896</li>
                <li><i class="fa fa-envelope" aria-hidden="true"></i>support@neon.com</li>
            </ul>
        </div>
        <div class="social-media">
                <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
        </div>
        </div>
    </div>
    <div class="footer-bottom">
        Copyright &copy; Neon 2020. All rights reserved.
    </div>
</div>








<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</body>
</html>