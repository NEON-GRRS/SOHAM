<?php include('register.php');?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Sign up</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script>-->
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

  <link rel="stylesheet" href="navbar.css">
  <link rel="stylesheet" href="footer.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  
    <link rel="stylesheet" href="footer.css">
  </head>
  <body>



    <!------------------------------navbar------------------------------------>
    <div class="bgimg">
      <nav class="navbar navbar-expand-md navbar-custom bg-dark navbar-dark  fixed-top">
       <!-- Brand -->
        <a class="navbar-brand" href="#"><img src="image/img11.jfif" alt="logo" width="70px"></a>

       <!-- Toggler/collapsibe Button -->
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
       </button>

        <!-- Navbar links -->
       <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#">About Us</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Booking History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Gallery</a>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Top Destinations
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Kolkata</a>
              <a class="dropdown-item" href="#">Asansol</a>
              <a class="dropdown-item" href="#">bhubaneswar</a>
            </div>
          </li>
          </li>
          <li class="nav-item mgr-autos" >
            <a class="nav-link" href="#">Log in</a>
          </li>
          
      </ul>
              
    </div>
    </nav>

</div>

<!--------navbar end------>

<div class=" container-fluid signupcustom">

      <form action="signup.php" class="signup-form" method="post">
          <h1>Sign up</h1>
           <?php include('errors.php');?>
          <div class="tb">
             <input type="text" name="name" placeholder="Full name"> 
          </div>
    
          <div class="tb">
             <input type="date" name="dob" placeholder="DoB">
          </div>
          <div class="tb">
             <input type="password" name="password" placeholder="Password">
         </div>
         <div class="tb">
            <input type="text" name="mobno" placeholder="Mobile No">
         </div>

        <div class="tb">
            <input type="email" name="email" placeholder="Email">
        </div>
        <div class="g-recaptcha" data-sitekey="6LeVOvIUAAAAAK_9Pzhoa-KkS2XzQjcz1gUJDFIB" required>
          
        </div>
        <input type="submit" name="signup" class="signupbtn" value="Sign up">
    </form>
<br><br>

</div>


<!-----------signup form end---------->

<!-- footer-->
    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1 class="footer-h1">NEON</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus velit ducimus, enim inventore earum, eligendi nostrum pariatur necessitatibus eius dicta a voluptates sit deleniti autem error eos totam nisi neque voluptates sit deleniti autem error eos totam nisi neque.</p>
            </div>
            <div class="footer-items">
               <h2 class="footer-h2">Quick Links</h2>
               <div class="border-footer"></div>
                  <ul>
                    <a href=""><li>Home</li></a>
                    <a href=""><li>About Us</li></a>
                    <a href=""><li>Contact Us</li></a>
                 </ul>
              </div>
              <div class="footer-items">
                 <h2 class="footer-h2">Services</h2>
                   <div class="border-footer"></div>
                  <ul>
                    <a href=""><li>Hotels</li></a>
                    <a href=""><li>Paying Guests</li></a>
                    <a href=""><li>Car Rentals</li></a>
                  </ul>
             </div>
             <div class="footer-items">
                <h2 class="footer-h2">Contact Us</h2>
                <div class="border-footer"></div>
                  <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i>XYZ Street, Kolkata</li>
                    <li><i class="fa fa-phone" aria-hidden="true"></i>1234567896</li>
                    <li><i class="fa fa-envelope" aria-hidden="true"></i>support@neon.com</li>
                 </ul>
              </div>
              <div class="social-media">
                <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
             </div>
        </div>
    </div>
    <div class="footer-bottom">
        Copyright &copy; Neon 2020. All rights reserved.
    </div>



       <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>