<?php
	
	$name="";
	$email="";
	$errors=array();
	$db=mysqli_connect('localhost','root','','neon');

	if(isset($_POST['signup'])) {
		$dob = $_POST['dob'];
		$password = $_POST['password'];
		$email = $_POST['email'];
		$name = $_POST['name'];
		
		$mobno = $_POST['mobno'];
		if(empty($name)){
			array_push($errors, "Name is required");
		}

		if(empty($password)){
			array_push($errors, "Password is required");
		}

		if(empty($dob)){
			array_push($errors, "DoB is required");
		}

		if(empty($email)){
			array_push($errors, "Email is required");
		}

		if(empty($mobno)){
			array_push($errors, "Mobile No. is required");
		}


		$secretKey="6LeVOvIUAAAAACqDpG_6xI7YJgX1Y63YFl1z0xAz";
		$responsekey=$_POST['g-recaptcha-response'];
		$UserIP= $_SERVER['REMOTE_ADDR'];
		$url="https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$responsekey&remoteip=$UserIP";
			
		$response= file_get_contents($url);

		$response=json_decode($response);


		if(count($errors)==0){
		
		if($response->success){

			$sql = "INSERT INTO registration(name,email,password,mobno,dob)
							VALUES ('$name','$email','$password','$mobno','$dob') ";
			mysqli_query($db, $sql);

			header("location:aboutus.php");
		}

		else {
			echo '<script type="text/javascript">alert("Invalid captcha, please try again"); 
		</script>';
		}
	}
	
	}



?>